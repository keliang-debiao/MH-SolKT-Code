# Artifact contract

A run is considered reviewer-auditable only when all required artifacts below exist.

## Formal training run

Required files:

- `run_metadata.json`: experiment family, configuration, seed, protocol, fold
- `model_provenance.json`: architecture family and implemented depth
- `split_manifest.json`: exact train/validation/test indices or fold definition
- `resolved_config.json`: fully merged runtime configuration
- `environment.json`: Python, PyTorch, CUDA, GPU, package versions, git commit, pip freeze
- `pip_freeze.txt`: plain-text environment lock snapshot
- `training_history.csv`: epoch loss, validation AUC, validation LogLoss, validation ECE, runtime
- `training_curve.png`: validation-AUC curve
- `validation_auc_history.csv`: checkpoint-selection history
- `checkpoint_metadata.json`: selected epoch, selected validation AUC, early-stop epoch, patience
- `validation_selection_metrics.json`: metrics at the selected checkpoint on validation data
- `final_test_metrics.json`: one-time held-out test evaluation
- `validation_predictions.npz`: validation labels/probabilities and diagnostics when available
- `test_predictions.npz`: test labels/probabilities and diagnostics when available

## Tables 5-7 audit source

The primary comparison must generate:

- `outputs/aggregated/primary_seed_level_source.csv`
- `outputs/aggregated/paired_auc_statistics.csv`

`audit_seed_statistics.py` recomputes paired values from the source CSV and fails on any mismatch.

## Student-wise five-fold protocol

The two-stage aggregation must generate:

- `student_wise_fivefold_fold_level_metrics.csv`
- `student_wise_fivefold_per_seed_metrics.csv`
- `student_wise_fivefold_summary_metrics.csv`

The logic is: average five folds within each seed, then compute mean and sample SD across seeds.

## Derived analyses

Temperature scaling must include source-run metadata and fitted temperature. Uncertainty and intervention analyses must include `analysis_metadata.json` linking each result to the source predictions.

## Submission gate

`verify_reviewer_completeness.py` must exit successfully before the reviewer evidence archive is exported.
