from __future__ import annotations

import argparse
import json
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path
import torch

EXPECTED = {
    "mamba-ssm": "2.3.1",
    "causal-conv1d": "1.5.4",
}


def get_version(name: str):
    try:
        return version(name)
    except PackageNotFoundError:
        return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify the documented official-Mamba sensitivity environment.")
    parser.add_argument("--output", default="outputs/official_mamba_environment_check.json")
    args = parser.parse_args()

    found = {name: get_version(name) for name in EXPECTED}
    report = {
        "python_torch_environment": {
            "torch": torch.__version__,
            "cuda_runtime": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
        "expected_packages": EXPECTED,
        "found_packages": found,
        "package_versions_match": all(found[k] == v for k, v in EXPECTED.items()),
        "official_mamba_importable": False,
    }
    try:
        from mamba_ssm import Mamba  # noqa: F401
        report["official_mamba_importable"] = True
    except Exception as exc:
        report["import_error"] = repr(exc)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if not (report["package_versions_match"] and report["official_mamba_importable"]):
        raise SystemExit("Official Mamba environment does not match the documented sensitivity environment.")


if __name__ == "__main__":
    main()
