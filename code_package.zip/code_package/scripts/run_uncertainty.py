from __future__ import annotations

from pathlib import Path
import numpy as np
from _common import OUTPUTS, SEEDS
from mhsolkt.evaluation.calibration import fit_temperature, apply_temperature
from mhsolkt.evaluation.uncertainty import predictive_entropy, inverse_max_probability, uncertainty_metrics, fit_calibration_aware_uncertainty, calibration_aware_score
from mhsolkt.utils.io import write_json


def load_npz(path: Path):
    if not path.exists():
        raise FileNotFoundError(path)
    return np.load(path)


def main():
    model_families = {
        "mhsolkt_384": OUTPUTS / "primary" / "mhsolkt_384",
        "mhsolkt": OUTPUTS / "primary" / "mhsolkt",
    }
    for seed in SEEDS:
        base = load_npz(model_families["mhsolkt_384"] / f"seed_{seed}" / "test_predictions.npz")
        val = load_npz(model_families["mhsolkt_384"] / f"seed_{seed}" / "validation_predictions.npz")
        raw = base["uncertainty"] if "uncertainty" in base.files else None
        val_raw = val["uncertainty"] if "uncertainty" in val.files else None
        temperature = fit_temperature(val["prob"], val["y_true"])
        temp_prob = apply_temperature(base["prob"], temperature)
        cal_model = fit_calibration_aware_uncertainty(val["y_true"], val["prob"], val_raw)
        score_map = {
            "raw_uncertainty_head_mhsolkt_384": raw,
            "predictive_entropy": predictive_entropy(base["prob"]),
            "inverse_max_probability": inverse_max_probability(base["prob"]),
            "temperature_scaled_entropy": predictive_entropy(temp_prob),
            "calibration_aware_uncertainty": calibration_aware_score(cal_model, base["prob"], raw),
        }
        standard_path = model_families["mhsolkt"] / f"seed_{seed}" / "test_predictions.npz"
        if standard_path.exists():
            standard = np.load(standard_path)
            if "uncertainty" in standard.files:
                score_map["raw_uncertainty_head_mhsolkt"] = standard["uncertainty"]
        for name, score in score_map.items():
            if score is None:
                continue
            out = OUTPUTS / "uncertainty" / name / f"seed_{seed}"
            out.mkdir(parents=True, exist_ok=True)
            write_json({
                "analysis": name,
                "seed": seed,
                "source_primary_run": str(model_families["mhsolkt_384"] / f"seed_{seed}"),
                "validation_used_for_fitting": name in {"temperature_scaled_entropy", "calibration_aware_uncertainty"},
            }, out / "analysis_metadata.json")
            write_json(uncertainty_metrics(base["y_true"], base["prob"], score), out / "metrics.json")


if __name__ == "__main__":
    main()
