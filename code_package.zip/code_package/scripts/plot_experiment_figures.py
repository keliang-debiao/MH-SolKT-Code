from __future__ import annotations

import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def save(fig, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_primary(source: pd.DataFrame, out: Path):
    summary = source.groupby("model")["auc"].agg(["mean", "std"]).sort_values("mean")
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(summary.index, summary["mean"], yerr=summary["std"], capsize=4)
    ax.set_ylabel("Mean AUC")
    ax.set_xlabel("Knowledge tracing model")
    ax.tick_params(axis="x", rotation=45)
    save(fig, out / "primary_auc.png")


def plot_seed_lines(source: pd.DataFrame, out: Path):
    fig, ax = plt.subplots(figsize=(10, 6))
    for model, group in source.groupby("model"):
        ax.plot(group["seed"], group["auc"], marker="o", label=model)
    ax.set_xlabel("Random seed")
    ax.set_ylabel("AUC")
    ax.legend()
    save(fig, out / "seed_stability.png")


def plot_training(history_path: Path, out: Path):
    h = pd.read_csv(history_path)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(h["epoch"], h["validation_auc"], marker="o")
    ax.set_xlabel("Training epochs")
    ax.set_ylabel("Validation AUC")
    save(fig, out / "training_trajectory.png")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--aggregated-dir", default="outputs/aggregated")
    p.add_argument("--figure-dir", default="outputs/figures")
    p.add_argument("--trajectory-history")
    args = p.parse_args()
    agg = Path(args.aggregated_dir)
    out = Path(args.figure_dir)
    source = pd.read_csv(agg / "primary_seed_level_source.csv")
    plot_primary(source, out)
    plot_seed_lines(source, out)
    if args.trajectory_history:
        plot_training(Path(args.trajectory_history), out)


if __name__ == "__main__":
    main()
