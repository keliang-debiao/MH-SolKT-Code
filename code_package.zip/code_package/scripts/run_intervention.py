from __future__ import annotations

from pathlib import Path
import numpy as np
from _common import OUTPUTS, SEEDS
from mhsolkt.evaluation.intervention import top_risk_metrics
from mhsolkt.utils.io import write_json

MODELS = ["dkt", "akt", "simplekt", "gikt", "mhsolkt", "mhsolkt_384"]


def resolve_prediction(model: str, seed: int) -> Path:
    return OUTPUTS / "primary" / model / f"seed_{seed}" / "test_predictions.npz"


def main():
    for model in MODELS:
        for seed in SEEDS:
            pred = np.load(resolve_prediction(model, seed))
            metrics = top_risk_metrics(pred["y_true"], pred["prob"], budgets=(0.05, 0.10, 0.20), ndcg_budget=0.10)
            out = OUTPUTS / "intervention" / model / f"seed_{seed}"
            out.mkdir(parents=True, exist_ok=True)
            write_json({
                "analysis": "top_risk_intervention",
                "model": model,
                "seed": seed,
                "source_predictions": str(resolve_prediction(model, seed)),
                "budgets": [0.05, 0.10, 0.20],
                "ndcg_budget": 0.10,
            }, out / "analysis_metadata.json")
            write_json(metrics, out / "metrics.json")


if __name__ == "__main__":
    main()
