from __future__ import annotations

from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.experiments.runner import run_config_file, resolve_config, run_experiment

MODELS = ["configs/baselines/dkt.yaml", "configs/proposed/mhsolkt_384.yaml"]


def main():
    protocol_templates = {
        "interaction_random": ROOT / "data/splits/interaction_random/seed_{seed}.json",
        "student_wise": ROOT / "data/splits/student_wise/seed_{seed}.json",
        "cold_start": ROOT / "data/splits/cold_start/seed_{seed}.json",
    }
    for protocol, template in protocol_templates.items():
        for rel in MODELS:
            # family/protocol are also inferable from output paths and split manifests;
            # keep the canonical experiment name unchanged for reliable aggregation.
            run_config_file(COMMON, ROOT / rel, str(template), OUTPUTS / "protocol_robustness" / protocol, SEEDS)

    for rel in MODELS:
        for seed in SEEDS:
            for fold in range(5):
                cfg = resolve_config(COMMON, ROOT / rel, seed)
                cfg["experiment"]["family"] = "protocol_robustness"
                cfg["experiment"]["protocol"] = "student_wise_fivefold"
                cfg["experiment"]["fold"] = fold
                exp_name = cfg["experiment"]["name"]
                manifest = ROOT / f"data/splits/student_wise_fivefold/seed_{seed}/fold_{fold}.json"
                run_dir = OUTPUTS / "protocol_robustness" / "student_wise_fivefold" / exp_name / f"seed_{seed}" / f"fold_{fold}"
                run_experiment(cfg, manifest, run_dir)


if __name__ == "__main__":
    main()
