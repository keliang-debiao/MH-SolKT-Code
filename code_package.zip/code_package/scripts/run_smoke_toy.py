from __future__ import annotations

from pathlib import Path
import torch

from _common import ROOT, COMMON, OUTPUTS
from mhsolkt.config import load_config, deep_update
from mhsolkt.data.toy import create_toy_dataset
from mhsolkt.data.splits import make_student_wise_manifest
from mhsolkt.experiments.runner import run_experiment

FORMAL_SMOKE_CONFIGS = [
    "configs/smoke/singpad_smoke_msolkt.yaml",
    "configs/smoke/smoke_dkt.yaml",
    "configs/smoke/smoke_causal_transformer.yaml",
]
TOY_CONFIG = "configs/smoke/toy_msolkt.yaml"


def run_one(config_path: Path, processed_dir: Path, manifest: Path, out_root: Path) -> None:
    cfg = deep_update(load_config(COMMON), load_config(config_path))
    cfg["data"]["processed_dir"] = str(processed_dir)
    run_experiment(cfg, manifest, out_root / cfg["experiment"]["name"])


def main() -> None:
    # Small CPU checks should not oversubscribe threads on large servers.
    torch.set_num_threads(1)

    # Always run the toy pipeline check.
    toy_dir = ROOT / "data/processed/toy"
    create_toy_dataset(toy_dir, students=12, length=24)
    toy_manifest = ROOT / "data/splits/toy_seed_123.json"
    make_student_wise_manifest(toy_dir / "sequences.pt", toy_manifest, seed=123, ratios=(0.7, 0.15, 0.15))
    run_one(ROOT / TOY_CONFIG, toy_dir, toy_manifest, OUTPUTS / "smoke_toy")

    # Run SingPAD/SingKT smoke checks only when the authorized processed data exist.
    formal_dir = ROOT / "data/processed/singpad"
    if not (formal_dir / "sequences.pt").exists():
        print("Authorized processed SingPAD/SingKT data not found; formal smoke checks were skipped. Toy check completed.")
        return

    formal_manifest = ROOT / "data/splits/smoke_seed_123.json"
    make_student_wise_manifest(formal_dir / "sequences.pt", formal_manifest, seed=123, ratios=(0.7, 0.15, 0.15))
    for rel in FORMAL_SMOKE_CONFIGS:
        run_one(ROOT / rel, formal_dir, formal_manifest, OUTPUTS / "smoke_toy")


if __name__ == "__main__":
    main()
