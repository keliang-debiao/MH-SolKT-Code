from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd

from _common import ROOT, OUTPUTS
from mhsolkt.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Export the representative validation trajectory from a real training run.")
    parser.add_argument("--config", default=str(ROOT / "configs/trajectory/representative.yaml"))
    parser.add_argument("--run-dir", default=None, help="Optional explicit run directory containing training_history.csv.")
    parser.add_argument("--output-dir", default=str(OUTPUTS / "training_trajectory"))
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.run_dir:
        run_dir = Path(args.run_dir)
        model = run_dir.parent.name
        seed = int(run_dir.name.split("_", 1)[1]) if run_dir.name.startswith("seed_") else None
    else:
        model = str(cfg["model"])
        seed = int(cfg["seed"])
        run_dir = ROOT / "outputs" / "primary" / model / f"seed_{seed}"

    history_path = run_dir / "training_history.csv"
    metadata_path = run_dir / "checkpoint_metadata.json"
    if not history_path.exists():
        raise FileNotFoundError(
            f"Missing {history_path}. Run the primary experiment for {model}, seed={seed} before exporting the trajectory."
        )

    history = pd.read_csv(history_path)
    required = {"epoch", "validation_auc"}
    missing = required - set(history.columns)
    if missing:
        raise ValueError(f"Training history is missing required columns: {sorted(missing)}")

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    history[["epoch", "validation_auc"]].to_csv(out_dir / "validation_auc_trajectory.csv", index=False)

    # Copy only run-identifying metadata derived from the real training run.
    summary = {
        "model": model,
        "seed": seed,
        "source_run_dir": str(run_dir),
        "source_history": str(history_path),
        "checkpoint_metadata": str(metadata_path) if metadata_path.exists() else None,
    }
    pd.DataFrame([summary]).to_csv(out_dir / "trajectory_source.csv", index=False)


if __name__ == "__main__":
    main()
