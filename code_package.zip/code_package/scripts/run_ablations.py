from __future__ import annotations

from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.experiments.runner import run_config_file

CONFIGS = [
    "configs/proposed/mhsolkt_384.yaml",
    "configs/proposed/mhsolkt.yaml",
    "configs/ablations/without_graph.yaml",
    "configs/ablations/without_uncertainty.yaml",
    "configs/ablations/without_mastery.yaml",
    "configs/ablations/without_graph_uncertainty.yaml",
    "configs/ablations/ssm_only.yaml",
    "configs/ablations/causal_lstm_only.yaml",
]


def main():
    manifest = str(ROOT / "data" / "splits" / "student_wise" / "seed_{seed}.json")
    for rel in CONFIGS:
        run_config_file(COMMON, ROOT / rel, manifest, OUTPUTS / "ablations", SEEDS)


if __name__ == "__main__":
    main()
