from __future__ import annotations

import argparse
from pathlib import Path
from _common import ROOT, SEEDS
from mhsolkt.config import load_config
from mhsolkt.data.dataset import load_sequences, make_windows
from mhsolkt.data.splits import make_student_wise_manifest, make_student_fivefold_manifests, make_interaction_window_manifest, make_cold_start_manifest


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default=str(ROOT / "configs" / "common.yaml"))
    args = p.parse_args()
    cfg = load_config(args.config)
    processed_dir = Path(cfg["data"]["processed_dir"])
    sequences_path = processed_dir / "sequences.pt"
    splits_dir = Path(cfg["data"]["splits_dir"])
    sequences, _ = load_sequences(processed_dir)
    windows = make_windows(sequences, int(cfg["training"]["max_sequence_length"]))
    ratios = tuple(cfg["data"].get("student_split_ratios", [0.7, 0.15, 0.15]))
    for seed in SEEDS:
        base = splits_dir / "student_wise" / f"seed_{seed}.json"
        make_student_wise_manifest(sequences_path, base, seed, ratios)
        make_student_fivefold_manifests(sequences_path, splits_dir / "student_wise_fivefold" / f"seed_{seed}", seed, folds=5)
        make_interaction_window_manifest(len(windows), splits_dir / "interaction_random" / f"seed_{seed}.json", seed, ratios)
        make_cold_start_manifest(sequences_path, base, splits_dir / "cold_start" / f"seed_{seed}.json", quantile=float(cfg["data"].get("cold_start_quantile", 0.25)))


if __name__ == "__main__":
    main()
