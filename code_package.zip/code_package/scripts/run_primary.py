from __future__ import annotations

from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.experiments.runner import run_config_file

CONFIGS = [
    "configs/baselines/dkt.yaml",
    "configs/baselines/dkvmn.yaml",
    "configs/baselines/sakt.yaml",
    "configs/baselines/saint.yaml",
    "configs/baselines/akt.yaml",
    "configs/baselines/gikt.yaml",
    "configs/baselines/simplekt.yaml",
    "configs/baselines/causal_transformer.yaml",
    "configs/proposed/mhsolkt.yaml",
    "configs/proposed/mhsolkt_384.yaml",
]


def main():
    manifest = str(ROOT / "data" / "splits" / "student_wise" / "seed_{seed}.json")
    for rel in CONFIGS:
        run_config_file(COMMON, ROOT / rel, manifest, OUTPUTS / "primary", SEEDS)


if __name__ == "__main__":
    main()
