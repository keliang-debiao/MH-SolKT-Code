from __future__ import annotations

import json
from pathlib import Path
import pandas as pd

try:
    from _common import OUTPUTS
except ImportError:  # imported as scripts.* during tests
    from scripts._common import OUTPUTS

METRICS = ["auc", "acc", "precision", "recall", "f1", "logloss", "brier", "rmse", "ece"]


def load_rows(root: Path) -> pd.DataFrame:
    rows: list[dict] = []
    family_root = root / "protocol_robustness" / "student_wise_fivefold"
    for path in family_root.rglob("final_test_metrics.json"):
        run_dir = path.parent
        meta_path = run_dir / "run_metadata.json"
        if not meta_path.exists():
            continue
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        metrics = json.loads(path.read_text(encoding="utf-8"))
        rows.append({**meta, **metrics})
    return pd.DataFrame(rows)


def aggregate_fivefold(root: Path = OUTPUTS) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    runs = load_rows(root)
    if runs.empty:
        return runs, pd.DataFrame(), pd.DataFrame()
    required = {"configuration_name", "seed", "fold"}
    missing = required - set(runs.columns)
    if missing:
        raise ValueError(f"five-fold runs are missing metadata columns: {sorted(missing)}")
    duplicate = runs.duplicated(["configuration_name", "seed", "fold"], keep=False)
    if duplicate.any():
        raise ValueError("duplicate model/seed/fold runs detected")

    metric_cols = [m for m in METRICS if m in runs.columns]
    counts = runs.groupby(["configuration_name", "seed"])["fold"].nunique()
    incomplete = counts[counts != 5]
    if not incomplete.empty:
        raise ValueError(f"incomplete five-fold groups detected: {incomplete.to_dict()}")

    per_seed = runs.groupby(["configuration_name", "seed"], as_index=False)[metric_cols].mean()
    rows = []
    for model, group in per_seed.groupby("configuration_name"):
        row = {"configuration_name": model, "n_seeds": int(group["seed"].nunique())}
        for metric in metric_cols:
            row[f"{metric}_mean"] = float(group[metric].mean())
            row[f"{metric}_sample_sd"] = float(group[metric].std(ddof=1))
        rows.append(row)
    summary = pd.DataFrame(rows)
    return runs, per_seed, summary


def main() -> None:
    out = OUTPUTS / "aggregated"
    out.mkdir(parents=True, exist_ok=True)
    runs, per_seed, summary = aggregate_fivefold(OUTPUTS)
    if not runs.empty:
        runs.to_csv(out / "student_wise_fivefold_fold_level_metrics.csv", index=False)
        per_seed.to_csv(out / "student_wise_fivefold_per_seed_metrics.csv", index=False)
        summary.to_csv(out / "student_wise_fivefold_summary_metrics.csv", index=False)


if __name__ == "__main__":
    main()
