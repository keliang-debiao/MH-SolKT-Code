from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

COMMON = ROOT / "configs" / "common.yaml"
SEEDS = [2024, 2025, 2026, 3407, 42]
OUTPUTS = ROOT / "outputs"
