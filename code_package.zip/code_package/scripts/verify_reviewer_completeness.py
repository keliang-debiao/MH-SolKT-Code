from __future__ import annotations

import argparse
import json
from pathlib import Path
from collections import defaultdict

FORMAL_RUN_FILES = {
    "run_metadata.json",
    "model_provenance.json",
    "split_manifest.json",
    "resolved_config.json",
    "environment.json",
    "pip_freeze.txt",
    "training_history.csv",
    "validation_auc_history.csv",
    "training_curve.png",
    "checkpoint_metadata.json",
    "validation_selection_metrics.json",
    "validation_predictions.npz",
    "final_test_metrics.json",
    "test_predictions.npz",
}

EXPECTED_FORMAL_COUNTS = {
    "primary": 50,
    "ablations": 40,
    "mamba_sensitivity": 25,
    "hidden_length_sensitivity": 25,
    "calibration": 20,
    "protocol_robustness": 80,
}

DERIVED_REQUIREMENTS = {
    "uncertainty": 30,
    "intervention": 30,
    "efficiency": 9,
}

AGGREGATED_REQUIRED = {
    "all_run_metrics.csv",
    "all_summary_metrics.csv",
    "primary_seed_level_source.csv",
    "paired_auc_statistics.csv",
    "student_wise_fivefold_fold_level_metrics.csv",
    "student_wise_fivefold_per_seed_metrics.csv",
    "student_wise_fivefold_summary_metrics.csv",
}


def formal_runs(outputs: Path):
    for metric_path in outputs.rglob("final_test_metrics.json"):
        run_dir = metric_path.parent
        if (run_dir / "training_history.csv").exists():
            yield run_dir


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify that all reviewer-requested reproducibility evidence is present after real runs.")
    parser.add_argument("--outputs", default="outputs")
    parser.add_argument("--report", default="outputs/reviewer_completeness_report.json")
    args = parser.parse_args()

    outputs = Path(args.outputs)
    counts = defaultdict(int)
    missing_by_run: dict[str, list[str]] = {}
    for run in formal_runs(outputs):
        meta = json.loads((run / "run_metadata.json").read_text(encoding="utf-8")) if (run / "run_metadata.json").exists() else {}
        family = str(meta.get("family", "unknown"))
        counts[family] += 1
        missing = sorted(name for name in FORMAL_RUN_FILES if not (run / name).exists())
        if missing:
            missing_by_run[str(run)] = missing

    count_checks = {
        family: {"expected": expected, "found": counts.get(family, 0), "ok": counts.get(family, 0) == expected}
        for family, expected in EXPECTED_FORMAL_COUNTS.items()
    }

    derived_checks = {
        "uncertainty": len(list((outputs / "uncertainty").rglob("metrics.json"))),
        "intervention": len(list((outputs / "intervention").rglob("metrics.json"))),
        "efficiency": len(list((outputs / "efficiency").rglob("efficiency.json"))),
    }
    derived_status = {
        name: {"expected": DERIVED_REQUIREMENTS[name], "found": found, "ok": found == DERIVED_REQUIREMENTS[name]}
        for name, found in derived_checks.items()
    }

    temperature_count = len(list((outputs / "calibration" / "temperature_scaling").rglob("final_test_metrics.json")))
    trajectory_ok = (outputs / "training_trajectory" / "validation_auc_trajectory.csv").exists() and (outputs / "training_trajectory" / "trajectory_source.csv").exists()
    aggregated_dir = outputs / "aggregated"
    aggregated_missing = sorted(name for name in AGGREGATED_REQUIRED if not (aggregated_dir / name).exists())

    report = {
        "formal_run_counts": count_checks,
        "formal_run_missing_artifacts": missing_by_run,
        "derived_analysis_counts": derived_status,
        "temperature_scaling": {"expected": 5, "found": temperature_count, "ok": temperature_count == 5},
        "training_trajectory": {"ok": trajectory_ok},
        "aggregated_missing": aggregated_missing,
    }
    report["complete"] = (
        all(x["ok"] for x in count_checks.values())
        and not missing_by_run
        and all(x["ok"] for x in derived_status.values())
        and report["temperature_scaling"]["ok"]
        and trajectory_ok
        and not aggregated_missing
    )

    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if not report["complete"]:
        raise SystemExit("Reviewer evidence package is incomplete. See the report for missing items.")


if __name__ == "__main__":
    main()
