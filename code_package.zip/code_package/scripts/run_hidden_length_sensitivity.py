from __future__ import annotations

from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.experiments.runner import run_config_file

CONFIGS = [
    "configs/sensitivity/hidden128_len200.yaml",
    "configs/sensitivity/hidden256_len200.yaml",
    "configs/sensitivity/hidden384_len100.yaml",
    "configs/sensitivity/hidden384_len200.yaml",
    "configs/sensitivity/hidden384_len300.yaml",
]


def main():
    manifest = str(ROOT / "data" / "splits" / "student_wise" / "seed_{seed}.json")
    for rel in CONFIGS:
        run_config_file(COMMON, ROOT / rel, manifest, OUTPUTS / "hidden_length_sensitivity", SEEDS)


if __name__ == "__main__":
    main()
