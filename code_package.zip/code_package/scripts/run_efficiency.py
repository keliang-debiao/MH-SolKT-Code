from __future__ import annotations

from pathlib import Path
import json
from torch.optim import AdamW
from _common import ROOT, COMMON, OUTPUTS
from mhsolkt.config import load_config, deep_update
from mhsolkt.data.dataset import build_loaders
from mhsolkt.models.registry import build_model
from mhsolkt.evaluation.efficiency import count_parameters, measure_epoch_runtime
from mhsolkt.utils.device import resolve_device
from mhsolkt.utils.io import write_json

CONFIGS = [
    "configs/baselines/dkt.yaml", "configs/baselines/dkvmn.yaml", "configs/baselines/sakt.yaml",
    "configs/baselines/akt.yaml", "configs/baselines/saint.yaml", "configs/baselines/simplekt.yaml",
    "configs/baselines/gikt.yaml", "configs/proposed/mhsolkt.yaml", "configs/proposed/mhsolkt_384.yaml",
]


def main():
    seed = 2024
    manifest = ROOT / f"data/splits/student_wise/seed_{seed}.json"
    device = resolve_device("auto")
    for rel in CONFIGS:
        cfg = deep_update(load_config(COMMON), load_config(ROOT / rel))
        cfg["experiment"]["seed"] = seed
        train, _, _, metadata = build_loaders(cfg, manifest)
        model = build_model(metadata, cfg).to(device)
        opt = AdamW(model.parameters(), lr=cfg["training"]["learning_rate"], weight_decay=cfg["training"]["weight_decay"])
        seconds = measure_epoch_runtime(model, train, opt, cfg, device)
        out = OUTPUTS / "efficiency" / cfg["experiment"]["name"]
        out.mkdir(parents=True, exist_ok=True)
        write_json({"trainable_parameters": count_parameters(model), "measured_epoch_seconds": seconds}, out / "efficiency.json")


if __name__ == "__main__":
    main()
