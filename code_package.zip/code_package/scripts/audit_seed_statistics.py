from __future__ import annotations

import argparse
import math
from pathlib import Path
import pandas as pd
from _common import OUTPUTS
from mhsolkt.evaluation.statistics import paired_table


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source", default=str(OUTPUTS / "aggregated/primary_seed_level_source.csv"))
    p.add_argument("--paired", default=str(OUTPUTS / "aggregated/paired_auc_statistics.csv"))
    p.add_argument("--reference", default="mhsolkt_384")
    p.add_argument("--tolerance", type=float, default=1e-12)
    args = p.parse_args()

    source = pd.read_csv(args.source)
    if source.duplicated(["model", "seed"]).any():
        raise AssertionError("The seed-level source contains duplicate model/seed rows.")
    expected = paired_table(args.source, args.reference, "auc").sort_values("comparison").reset_index(drop=True)
    reported = pd.read_csv(args.paired).sort_values("comparison").reset_index(drop=True)
    cols = ["mean_delta", "paired_sd", "cohens_d_av", "n"]
    if list(expected["comparison"]) != list(reported["comparison"]):
        raise AssertionError("Paired comparison sets do not match the source CSV.")
    for col in cols:
        diff = (expected[col] - reported[col]).abs().max()
        if not (math.isnan(diff) or diff <= args.tolerance):
            raise AssertionError(f"Mismatch in {col}: max absolute difference={diff}")
    print("Seed-level source and paired-statistics file are exactly consistent.")


if __name__ == "__main__":
    main()
