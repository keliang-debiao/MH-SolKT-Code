from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Create SHA-256 checksums for reviewer-facing artifacts.")
    parser.add_argument("--root", default="outputs")
    parser.add_argument("--output", default="outputs/SHA256SUMS.txt")
    args = parser.parse_args()
    root = Path(args.root)
    out = Path(args.output)
    files = sorted(p for p in root.rglob("*") if p.is_file() and p.resolve() != out.resolve())
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for path in files:
            f.write(f"{sha256(path)}  {path.relative_to(root).as_posix()}\n")
    print(f"Wrote {len(files)} checksums to {out}")


if __name__ == "__main__":
    main()
