from __future__ import annotations

import argparse
from _common import ROOT, SRC
from mhsolkt.config import load_config
from mhsolkt.data.preprocess import preprocess_dataset


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default=str(ROOT / "configs" / "common.yaml"))
    args = p.parse_args()
    preprocess_dataset(load_config(args.config))


if __name__ == "__main__":
    main()
