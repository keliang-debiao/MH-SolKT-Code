from __future__ import annotations

import argparse
from itertools import product
from pathlib import Path
import json
import pandas as pd
import yaml

from _common import ROOT, COMMON, OUTPUTS
from mhsolkt.config import load_config, save_config, deep_update
from mhsolkt.experiments.runner import resolve_config, run_experiment
from mhsolkt.utils.io import write_json


def set_dotted(cfg: dict, key: str, value) -> None:
    cursor = cfg
    parts = key.split(".")
    for part in parts[:-1]:
        cursor = cursor.setdefault(part, {})
    cursor[parts[-1]] = value


def candidates(grid: dict[str, list]) -> list[dict]:
    keys = list(grid)
    return [dict(zip(keys, values)) for values in product(*(grid[k] for k in keys))]


def main() -> None:
    parser = argparse.ArgumentParser(description="Validation-only predefined-grid search for reproduced baselines.")
    parser.add_argument("--grid", default=str(ROOT / "configs/tuning_grids/baselines.yaml"))
    parser.add_argument("--models", nargs="*", default=None)
    args = parser.parse_args()

    spec = load_config(args.grid)
    tuning = spec["tuning"]
    selected_models = set(args.models or spec["models"].keys())
    manifest_template = ROOT / "data/splits/student_wise/seed_{seed}.json"
    tuning_root = OUTPUTS / "hyperparameter_search"

    for model_name, model_spec in spec["models"].items():
        if model_name not in selected_models:
            continue
        base_path = ROOT / model_spec["config"]
        rows = []
        for idx, patch in enumerate(candidates(model_spec.get("grid", {}))):
            candidate_name = f"candidate_{idx:03d}"
            candidate_dir = tuning_root / model_name / candidate_name
            candidate_cfg_path = candidate_dir / "candidate_config.yaml"
            base_exp = load_config(base_path)
            for key, value in patch.items():
                set_dotted(base_exp, key, value)
            base_exp["experiment"]["name"] = f"{model_name}__{candidate_name}"
            base_exp["experiment"]["family"] = "hyperparameter_search"
            base_exp["experiment"]["protocol"] = "student_wise"
            base_exp.setdefault("evaluation", {})["evaluate_test"] = False
            save_config(base_exp, candidate_cfg_path)

            for seed in tuning["seeds"]:
                cfg = deep_update(load_config(COMMON), base_exp)
                cfg["experiment"]["seed"] = int(seed)
                cfg.setdefault("evaluation", {})["evaluate_test"] = False
                run_dir = candidate_dir / f"seed_{seed}"
                run_experiment(cfg, Path(str(manifest_template).format(seed=seed)), run_dir)
                metrics = json.loads((run_dir / "validation_selection_metrics.json").read_text(encoding="utf-8"))
                rows.append({"model": model_name, "candidate": candidate_name, "seed": seed, **patch, **metrics})

        results = pd.DataFrame(rows)
        results.to_csv(tuning_root / model_name / "validation_search_logs.csv", index=False)
        score = tuning.get("selection_metric", "validation_auc")
        ranking = results.groupby("candidate", as_index=False)[score].mean().sort_values(score, ascending=False)
        ranking.to_csv(tuning_root / model_name / "validation_ranking.csv", index=False)
        best = str(ranking.iloc[0]["candidate"])
        selected_path = tuning_root / model_name / best / "candidate_config.yaml"
        selected_cfg = load_config(selected_path)
        save_config(selected_cfg, tuning_root / model_name / "selected_config.yaml")
        write_json({
            "selection_metric": score,
            "selection_rule": "highest mean validation metric; test set never evaluated during search",
            "tuning_seeds": tuning["seeds"],
            "selected_candidate": best,
            "selected_config": str(selected_path),
        }, tuning_root / model_name / "selection_record.json")


if __name__ == "__main__":
    main()
