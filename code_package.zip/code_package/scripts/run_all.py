from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys
import yaml

from _common import ROOT


def main() -> None:
    parser = argparse.ArgumentParser(description="Run every MH-SolKT experiment family described in the manuscript.")
    parser.add_argument("--manifest", default=str(ROOT / "configs/experiment_manifest.yaml"))
    parser.add_argument("--skip", nargs="*", default=[])
    parser.add_argument("--include-optional", nargs="*", default=[], help="Optional families such as hyperparameter_search.")
    parser.add_argument("--prepare-data", action="store_true", help="Run preprocessing and split construction before experiments.")
    args = parser.parse_args()

    if args.prepare_data:
        subprocess.run([sys.executable, str(ROOT / "scripts/preprocess_singpad.py")], check=True, cwd=ROOT)
        subprocess.run([sys.executable, str(ROOT / "scripts/make_splits.py")], check=True, cwd=ROOT)

    with Path(args.manifest).open("r", encoding="utf-8") as f:
        manifest = yaml.safe_load(f)

    skipped = set(args.skip)
    included_optional = set(args.include_optional)
    for family in manifest["families"]:
        name = family["name"]
        if name in skipped:
            continue
        if family.get("enabled_by_default", True) is False and name not in included_optional:
            continue
        script = ROOT / family["script"]
        subprocess.run([sys.executable, str(script)], check=True, cwd=ROOT)


if __name__ == "__main__":
    main()
