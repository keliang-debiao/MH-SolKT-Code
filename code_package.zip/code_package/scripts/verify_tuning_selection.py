from __future__ import annotations

import argparse
from pathlib import Path
import yaml

from _common import ROOT, OUTPUTS
from mhsolkt.config import load_config

BASELINE_DIR = ROOT / "configs/baselines"
IGNORE_MODEL_KEYS = {"name"}


def comparable(cfg: dict) -> dict:
    return {k: v for k, v in cfg.get("model", {}).items() if k not in IGNORE_MODEL_KEYS}


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify that final baseline configs match validation-selected configs.")
    parser.add_argument("--tuning-root", default=str(OUTPUTS / "hyperparameter_search"))
    args = parser.parse_args()
    tuning_root = Path(args.tuning_root)
    mismatches = []
    checked = 0
    for final_path in sorted(BASELINE_DIR.glob("*.yaml")):
        model = final_path.stem
        selected_path = tuning_root / model / "selected_config.yaml"
        if not selected_path.exists():
            continue
        checked += 1
        final_cfg = load_config(final_path)
        selected_cfg = load_config(selected_path)
        if comparable(final_cfg) != comparable(selected_cfg):
            mismatches.append(model)
    if checked == 0:
        raise SystemExit("No selected tuning configs were found. Run run_hyperparameter_search.py first.")
    if mismatches:
        raise SystemExit(f"Final baseline configs do not match validation-selected configs: {mismatches}")
    print(f"All {checked} tuned baseline configurations match the validation-selected configs.")


if __name__ == "__main__":
    main()
