from __future__ import annotations

import argparse

from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.experiments.runner import run_config_file

FALLBACK_CONFIGS = [
    "configs/sensitivity/fallback_h384.yaml",
    "configs/sensitivity/fallback_h256.yaml",
    "configs/sensitivity/fallback_h128.yaml",
]
OFFICIAL_CONFIGS = [
    "configs/sensitivity/official_h384.yaml",
    "configs/sensitivity/official_h256.yaml",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run fallback and/or official-Mamba implementation sensitivity experiments.")
    parser.add_argument("--mode", choices=["all", "fallback", "official"], default="all")
    args = parser.parse_args()

    if args.mode == "fallback":
        configs = FALLBACK_CONFIGS
    elif args.mode == "official":
        configs = OFFICIAL_CONFIGS
    else:
        configs = FALLBACK_CONFIGS + OFFICIAL_CONFIGS

    manifest = str(ROOT / "data" / "splits" / "student_wise" / "seed_{seed}.json")
    for rel in configs:
        run_config_file(COMMON, ROOT / rel, manifest, OUTPUTS / "mamba_sensitivity", SEEDS)


if __name__ == "__main__":
    main()
