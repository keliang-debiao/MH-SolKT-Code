from __future__ import annotations

import json
from pathlib import Path
import pandas as pd
try:
    from _common import OUTPUTS
except ImportError:  # imported as scripts.* during tests
    from scripts._common import OUTPUTS
from mhsolkt.evaluation.statistics import paired_table
from aggregate_protocol_fivefold import aggregate_fivefold

METRICS = ["auc", "acc", "precision", "recall", "f1", "logloss", "brier", "rmse", "ece"]


def scan_metrics(root: Path) -> pd.DataFrame:
    rows = []
    for path in root.rglob("final_test_metrics.json"):
        run_dir = path.parent
        meta_path = run_dir / "run_metadata.json"
        config_path = run_dir / "resolved_config.json"
        if meta_path.exists():
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        elif config_path.exists():
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            meta = {
                "family": "unknown",
                "configuration_name": cfg["experiment"]["name"],
                "model_name": cfg["model"]["name"],
                "seed": cfg["experiment"].get("seed"),
                "protocol": None,
                "fold": None,
            }
        else:
            continue
        metrics = json.loads(path.read_text(encoding="utf-8"))
        rows.append({**meta, "run_dir": str(run_dir), **metrics})
    return pd.DataFrame(rows)


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    metric_cols = [c for c in METRICS if c in df.columns]
    rows = []
    for (family, model), group in df.groupby(["family", "configuration_name"], dropna=False):
        row = {"family": family, "configuration_name": model, "n_runs": len(group)}
        for metric in metric_cols:
            row[f"{metric}_mean"] = group[metric].mean()
            row[f"{metric}_sample_sd"] = group[metric].std(ddof=1)
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    out_dir = OUTPUTS / "aggregated"
    out_dir.mkdir(parents=True, exist_ok=True)
    runs = scan_metrics(OUTPUTS)
    runs.to_csv(out_dir / "all_run_metrics.csv", index=False)
    summarize(runs).to_csv(out_dir / "all_summary_metrics.csv", index=False)

    primary = runs[(runs["family"] == "primary") & runs["seed"].notna()].copy() if not runs.empty else pd.DataFrame()
    if not primary.empty:
        source_cols = [c for c in ["configuration_name", "seed", *METRICS] if c in primary.columns]
        source = primary[source_cols].rename(columns={"configuration_name": "model"}).sort_values(["model", "seed"])
        source.to_csv(out_dir / "primary_seed_level_source.csv", index=False)
        reference = "mhsolkt_384"
        if reference in set(source["model"]):
            paired_table(str(out_dir / "primary_seed_level_source.csv"), reference_model=reference, metric="auc").to_csv(out_dir / "paired_auc_statistics.csv", index=False)

    fold_runs, per_seed, fold_summary = aggregate_fivefold(OUTPUTS)
    if not fold_runs.empty:
        fold_runs.to_csv(out_dir / "student_wise_fivefold_fold_level_metrics.csv", index=False)
        per_seed.to_csv(out_dir / "student_wise_fivefold_per_seed_metrics.csv", index=False)
        fold_summary.to_csv(out_dir / "student_wise_fivefold_summary_metrics.csv", index=False)


if __name__ == "__main__":
    main()
