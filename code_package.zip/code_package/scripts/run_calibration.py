from __future__ import annotations

from pathlib import Path
import numpy as np
from _common import ROOT, COMMON, SEEDS, OUTPUTS
from mhsolkt.config import load_config, deep_update
from mhsolkt.experiments.runner import run_config_file
from mhsolkt.evaluation.calibration import fit_temperature, apply_temperature
from mhsolkt.evaluation.metrics import binary_metrics
from mhsolkt.utils.io import write_json

TRAINING_CONFIGS = [
    "configs/calibration/uncalibrated.yaml",
    "configs/calibration/label_smoothing.yaml",
    "configs/calibration/brier_auxiliary.yaml",
    "configs/calibration/focal_loss.yaml",
]


def main():
    manifest = str(ROOT / "data" / "splits" / "student_wise" / "seed_{seed}.json")
    for rel in TRAINING_CONFIGS:
        run_config_file(COMMON, ROOT / rel, manifest, OUTPUTS / "calibration", SEEDS)

    base_name = load_config(ROOT / "configs/calibration/uncalibrated.yaml")["experiment"]["name"]
    for seed in SEEDS:
        run_dir = OUTPUTS / "calibration" / base_name / f"seed_{seed}"
        val_path = run_dir / "validation_predictions.npz"
        test_path = run_dir / "test_predictions.npz"
        if not val_path.exists():
            raise FileNotFoundError(
                f"{val_path} is required for post-hoc temperature scaling. "
                "Enable validation prediction export before running this script."
            )
        val = np.load(val_path)
        test = np.load(test_path)
        temperature = fit_temperature(val["prob"], val["y_true"])
        calibrated = apply_temperature(test["prob"], temperature)
        out_dir = OUTPUTS / "calibration" / "temperature_scaling" / f"seed_{seed}"
        out_dir.mkdir(parents=True, exist_ok=True)
        write_json({"temperature": temperature}, out_dir / "calibration_parameters.json")
        write_json({
            "analysis": "post_hoc_temperature_scaling",
            "seed": seed,
            "source_run": str(run_dir),
            "fit_split": "validation",
            "evaluation_split": "test",
        }, out_dir / "analysis_metadata.json")
        write_json(binary_metrics(test["y_true"], calibrated), out_dir / "final_test_metrics.json")
        np.savez_compressed(out_dir / "test_predictions.npz", y_true=test["y_true"], prob=calibrated)


if __name__ == "__main__":
    main()
