from __future__ import annotations

from .mhsolkt import MHSolKT
from .baselines import DKT, DKVMN, SAKT, SAINT, AKT, GIKT, SimpleKT, CausalTransformer


def build_model(metadata: dict, cfg: dict):
    name = cfg["model"]["name"].lower()
    registry = {
        "dkt": DKT,
        "dkvmn": DKVMN,
        "sakt": SAKT,
        "saint": SAINT,
        "akt": AKT,
        "gikt": GIKT,
        "simplekt": SimpleKT,
        "causal_transformer": CausalTransformer,
        "mhsolkt": MHSolKT,
        "m_solkt": MHSolKT,
    }
    if name not in registry:
        raise KeyError(f"Unknown model: {name}")
    return registry[name](metadata, cfg)
