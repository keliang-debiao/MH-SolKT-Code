from __future__ import annotations

import math
import torch
from torch import nn


class InteractionEncoder(nn.Module):
    def __init__(self, metadata: dict, embedding_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.item = nn.Embedding(metadata["num_items"], embedding_dim, padding_idx=0)
        self.concept = nn.Embedding(metadata["num_concepts"], embedding_dim, padding_idx=0)
        self.score = nn.Embedding(metadata["num_scores"], embedding_dim, padding_idx=0)
        self.response = nn.Embedding(2, embedding_dim)
        aux_dim = int(metadata.get("aux_dim", 0))
        self.aux = nn.Linear(aux_dim, embedding_dim) if aux_dim > 0 else None
        parts = 4 + (1 if self.aux is not None else 0)
        self.proj = nn.Linear(parts * embedding_dim, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        parts = [
            self.item(batch["item_id"]),
            self.concept(batch["concept_id"]),
            self.score(batch["score_id"]),
            self.response(batch["response"].long().clamp(0, 1)),
        ]
        if self.aux is not None:
            parts.append(self.aux(batch["aux"]))
        x = torch.cat(parts, dim=-1)
        return self.dropout(self.norm(self.proj(x)))


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 4096):
        super().__init__()
        pos = torch.arange(max_len).float().unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, d_model)
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, :x.size(1)]


def causal_mask(length: int, device: torch.device) -> torch.Tensor:
    return torch.triu(torch.ones(length, length, device=device, dtype=torch.bool), diagonal=1)


class GraphEncoder(nn.Module):
    def __init__(self, metadata: dict, hidden_dim: int, layers: int = 2, dropout: float = 0.2):
        super().__init__()
        self.num_items = metadata["num_items"]
        self.num_concepts = metadata["num_concepts"]
        self.node_embedding = nn.Embedding(self.num_items + self.num_concepts, hidden_dim)
        self.layers = nn.ModuleList(nn.Linear(hidden_dim, hidden_dim, bias=False) for _ in range(layers))
        self.dropout = nn.Dropout(dropout)
        from mhsolkt.data.graph import build_bipartite_adjacency
        adj = build_bipartite_adjacency(self.num_items, self.num_concepts, metadata.get("item_concept_edges", []))
        self.register_buffer("adj", adj, persistent=False)

    def forward(self, item_id: torch.Tensor, concept_id: torch.Tensor) -> torch.Tensor:
        h = self.node_embedding.weight
        for layer in self.layers:
            h = torch.relu(layer(self.adj @ h))
            h = self.dropout(h)
        item_h = h[item_id]
        concept_h = h[self.num_items + concept_id]
        return 0.5 * (item_h + concept_h)


class SelectiveStateSpaceFallback(nn.Module):
    """Causal selective state-tracking fallback used when the official Mamba kernel is absent."""

    def __init__(self, hidden_dim: int, dropout: float = 0.2):
        super().__init__()
        self.in_proj = nn.Linear(hidden_dim, hidden_dim * 3)
        self.depthwise = nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=2, groups=hidden_dim)
        self.state_proj = nn.Linear(hidden_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate, proposal, skip = self.in_proj(x).chunk(3, dim=-1)
        gate = torch.sigmoid(gate)
        proposal = torch.tanh(proposal)
        conv = self.depthwise(x.transpose(1, 2))[..., : x.size(1)].transpose(1, 2)
        proposal = proposal + torch.tanh(conv)
        state = torch.zeros_like(x[:, 0])
        outputs = []
        for t in range(x.size(1)):
            state = gate[:, t] * state + (1.0 - gate[:, t]) * proposal[:, t]
            state = torch.tanh(self.state_proj(state))
            outputs.append(state + skip[:, t])
        y = torch.stack(outputs, dim=1)
        return self.dropout(self.norm(self.out_proj(y) + x))


class StackedSelectiveStateSpaceFallback(nn.Module):
    """Stack multiple causal fallback state-space blocks with explicit depth."""

    def __init__(self, hidden_dim: int, layers: int = 1, dropout: float = 0.2):
        super().__init__()
        if layers < 1:
            raise ValueError("layers must be >= 1")
        self.blocks = nn.ModuleList([SelectiveStateSpaceFallback(hidden_dim, dropout) for _ in range(layers)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block in self.blocks:
            x = block(x)
        return x


class OfficialMambaAdapter(nn.Module):
    def __init__(self, hidden_dim: int, layers: int = 1):
        super().__init__()
        try:
            from mamba_ssm import Mamba
        except Exception as exc:
            raise RuntimeError(
                "Official Mamba experiment requested but mamba-ssm is not importable. "
                "Install requirements-official-mamba.txt in a compatible CUDA environment."
            ) from exc
        self.blocks = nn.ModuleList([Mamba(d_model=hidden_dim, d_state=16, d_conv=4, expand=2) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden_dim) for _ in range(layers)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block, norm in zip(self.blocks, self.norms):
            x = norm(x + block(x))
        return x
