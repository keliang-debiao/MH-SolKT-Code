from __future__ import annotations

import math
from typing import Any

import torch
from torch import nn

from .components import InteractionEncoder, PositionalEncoding, causal_mask, GraphEncoder


class BaseKT(nn.Module):
    """Base class for reproduced knowledge-tracing baselines.

    Each implementation exposes explicit provenance metadata so every run can record
    which architecture family was executed. The implementations are intentionally
    distinct; no baseline is an alias of another baseline class.
    """

    reproduction_metadata: dict[str, Any] = {}

    def _out(self, h: torch.Tensor) -> dict[str, torch.Tensor]:
        return {"logits": self.head(h).squeeze(-1), "hidden": h}


class DKT(BaseKT):
    reproduction_metadata = {
        "family": "recurrent",
        "architecture": "LSTM-based Deep Knowledge Tracing",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        layers = int(m.get("layers", 1))
        self.enc = InteractionEncoder(metadata, m["embedding_dim"], m["hidden_dim"], m["dropout"])
        self.rnn = nn.LSTM(
            m["hidden_dim"],
            m["hidden_dim"],
            num_layers=layers,
            batch_first=True,
            dropout=m["dropout"] if layers > 1 else 0.0,
        )
        self.head = nn.Linear(m["hidden_dim"], 1)

    def forward(self, batch):
        h, _ = self.rnn(self.enc(batch))
        return self._out(h)


class DKVMN(BaseKT):
    reproduction_metadata = {
        "family": "memory_augmented",
        "architecture": "Dynamic Key-Value Memory Network",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        e = int(m["embedding_dim"])
        self.question_item = nn.Embedding(metadata["num_items"], e, padding_idx=0)
        self.question_concept = nn.Embedding(metadata["num_concepts"], e, padding_idx=0)
        self.response = nn.Embedding(2, e)
        self.question_proj = nn.Linear(e * 2, d)
        self.interaction_proj = nn.Linear(e * 3, d)
        memory_size = int(m.get("memory_size", 64))
        self.keys = nn.Parameter(torch.randn(memory_size, d) / math.sqrt(d))
        self.init_values = nn.Parameter(torch.zeros(memory_size, d))
        self.erase = nn.Linear(d, d)
        self.add = nn.Linear(d, d)
        self.read_proj = nn.Linear(d * 2, d)
        self.dropout = nn.Dropout(float(m["dropout"]))
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        qi = self.question_item(batch["item_id"])
        qc = self.question_concept(batch["concept_id"])
        r = self.response(batch["response"].long().clamp(0, 1))
        q_seq = torch.tanh(self.question_proj(torch.cat([qi, qc], dim=-1)))
        interaction = torch.tanh(self.interaction_proj(torch.cat([qi, qc, r], dim=-1)))
        b, t, d = q_seq.shape
        values = self.init_values.unsqueeze(0).expand(b, -1, -1).clone()
        outputs = []
        for i in range(t):
            q = q_seq[:, i]
            x = interaction[:, i]
            attn = torch.softmax(q @ self.keys.t() / math.sqrt(d), dim=-1)
            read = torch.einsum("bm,bmd->bd", attn, values)
            outputs.append(torch.tanh(self.read_proj(torch.cat([q, read], dim=-1))))
            erase = torch.sigmoid(self.erase(x)).unsqueeze(1)
            add = torch.tanh(self.add(x)).unsqueeze(1)
            w = attn.unsqueeze(-1)
            values = values * (1 - w * erase) + w * add
        return self._out(self.dropout(torch.stack(outputs, dim=1)))


class CausalTransformer(BaseKT):
    reproduction_metadata = {
        "family": "causal_attention",
        "architecture": "Generic causal Transformer sequence baseline",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.enc = InteractionEncoder(metadata, m["embedding_dim"], d, m["dropout"])
        self.pos = PositionalEncoding(d)
        layer = nn.TransformerEncoderLayer(
            d_model=d,
            nhead=int(m.get("heads", 8)),
            dim_feedforward=d * 4,
            dropout=float(m["dropout"]),
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=int(m.get("layers", 3)))
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        x = self.pos(self.enc(batch))
        mask = causal_mask(x.size(1), x.device)
        h = self.transformer(x, mask=mask, src_key_padding_mask=~batch["mask"])
        return self._out(h)


class _SAKTBlock(nn.Module):
    def __init__(self, d: int, heads: int, dropout: float):
        super().__init__()
        self.attn = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d)
        self.ffn = nn.Sequential(nn.Linear(d, d * 2), nn.ReLU(), nn.Dropout(dropout), nn.Linear(d * 2, d))
        self.norm2 = nn.LayerNorm(d)
        self.dropout = nn.Dropout(dropout)

    def forward(self, query: torch.Tensor, interaction: torch.Tensor, padding_mask: torch.Tensor) -> torch.Tensor:
        attn_mask = causal_mask(query.size(1), query.device)
        z, _ = self.attn(
            query=query,
            key=interaction,
            value=interaction,
            attn_mask=attn_mask,
            key_padding_mask=padding_mask,
            need_weights=False,
        )
        h = self.norm1(query + self.dropout(z))
        return self.norm2(h + self.dropout(self.ffn(h)))


class SAKT(BaseKT):
    """SAKT-style query-to-past-interaction self-attention.

    This is not an alias of the generic causal Transformer. Questions form the
    queries, while response-conditioned interaction embeddings form keys/values.
    """

    reproduction_metadata = {
        "family": "self_attention",
        "architecture": "SAKT-style question-query / interaction-key-value attention",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.item = nn.Embedding(metadata["num_items"], d, padding_idx=0)
        self.concept = nn.Embedding(metadata["num_concepts"], d, padding_idx=0)
        self.response = nn.Embedding(2, d)
        self.pos_q = PositionalEncoding(d)
        self.pos_x = PositionalEncoding(d)
        self.blocks = nn.ModuleList(
            [_SAKTBlock(d, int(m.get("heads", 8)), float(m["dropout"])) for _ in range(int(m.get("layers", 2)))]
        )
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        raw_q = self.item(batch["item_id"]) + self.concept(batch["concept_id"])
        q = self.pos_q(raw_q)
        interaction = self.pos_x(raw_q + self.response(batch["response"].long().clamp(0, 1)))
        h = q
        padding_mask = ~batch["mask"]
        for block in self.blocks:
            h = block(h, interaction, padding_mask)
            interaction = interaction + h
        return self._out(h)


class SAINT(BaseKT):
    reproduction_metadata = {
        "family": "encoder_decoder_attention",
        "architecture": "SAINT-style exercise encoder and response decoder",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.exercise_item = nn.Embedding(metadata["num_items"], d, padding_idx=0)
        self.exercise_concept = nn.Embedding(metadata["num_concepts"], d, padding_idx=0)
        self.response = nn.Embedding(2, d)
        self.pos = PositionalEncoding(d)
        enc_layer = nn.TransformerEncoderLayer(d, int(m.get("heads", 8)), d * 4, m["dropout"], batch_first=True, norm_first=True)
        dec_layer = nn.TransformerDecoderLayer(d, int(m.get("heads", 8)), d * 4, m["dropout"], batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc_layer, int(m.get("layers", 2)))
        self.decoder = nn.TransformerDecoder(dec_layer, int(m.get("layers", 2)))
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        exercise = self.pos(self.exercise_item(batch["item_id"]) + self.exercise_concept(batch["concept_id"]))
        memory = self.encoder(exercise, src_key_padding_mask=~batch["mask"])
        target = self.pos(self.response(batch["response"].long().clamp(0, 1)))
        mask = causal_mask(target.size(1), target.device)
        h = self.decoder(
            target,
            memory,
            tgt_mask=mask,
            tgt_key_padding_mask=~batch["mask"],
            memory_key_padding_mask=~batch["mask"],
        )
        return self._out(h)


class _AKTBlock(nn.Module):
    def __init__(self, d: int, heads: int, dropout: float):
        super().__init__()
        if d % heads != 0:
            raise ValueError("hidden_dim must be divisible by number of heads")
        self.heads = heads
        self.head_dim = d // heads
        self.scale = self.head_dim ** -0.5
        self.q = nn.Linear(d, d)
        self.k = nn.Linear(d, d)
        self.v = nn.Linear(d, d)
        self.out = nn.Linear(d, d)
        self.gamma = nn.Parameter(torch.zeros(heads))
        self.norm1 = nn.LayerNorm(d)
        self.ffn = nn.Sequential(nn.Linear(d, d * 4), nn.ReLU(), nn.Dropout(dropout), nn.Linear(d * 4, d))
        self.norm2 = nn.LayerNorm(d)
        self.dropout = nn.Dropout(dropout)

    def forward(self, q_input: torch.Tensor, kv_input: torch.Tensor, valid_mask: torch.Tensor) -> torch.Tensor:
        b, t, d = q_input.shape
        q = self.q(q_input).view(b, t, self.heads, self.head_dim).transpose(1, 2)
        k = self.k(kv_input).view(b, t, self.heads, self.head_dim).transpose(1, 2)
        v = self.v(kv_input).view(b, t, self.heads, self.head_dim).transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        idx = torch.arange(t, device=q_input.device)
        distance = (idx[:, None] - idx[None, :]).clamp_min(0).float()
        decay = torch.nn.functional.softplus(self.gamma).view(1, self.heads, 1, 1)
        scores = scores - decay * distance.view(1, 1, t, t)
        future = causal_mask(t, q_input.device).view(1, 1, t, t)
        scores = scores.masked_fill(future, torch.finfo(scores.dtype).min)
        key_padding = (~valid_mask).view(b, 1, 1, t)
        scores = scores.masked_fill(key_padding, torch.finfo(scores.dtype).min)
        attn = torch.softmax(scores, dim=-1)
        z = torch.matmul(attn, v).transpose(1, 2).contiguous().view(b, t, d)
        h = self.norm1(q_input + self.dropout(self.out(z)))
        return self.norm2(h + self.dropout(self.ffn(h)))


class AKT(BaseKT):
    reproduction_metadata = {
        "family": "context_aware_attention",
        "architecture": "AKT-style monotonic distance-decayed attention",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.item = nn.Embedding(metadata["num_items"], d, padding_idx=0)
        self.concept = nn.Embedding(metadata["num_concepts"], d, padding_idx=0)
        self.response = nn.Embedding(2, d)
        self.question_difficulty = nn.Embedding(metadata["num_items"], 1, padding_idx=0)
        self.difficulty_direction = nn.Parameter(torch.zeros(d))
        self.blocks = nn.ModuleList(
            [_AKTBlock(d, int(m.get("heads", 8)), float(m["dropout"])) for _ in range(int(m.get("layers", 2)))]
        )
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        q = self.item(batch["item_id"]) + self.concept(batch["concept_id"])
        difficulty = self.question_difficulty(batch["item_id"]) * self.difficulty_direction.view(1, 1, -1)
        q = q + difficulty
        interaction = q + self.response(batch["response"].long().clamp(0, 1))
        h = q
        for block in self.blocks:
            h = block(h, interaction, batch["mask"])
            interaction = interaction + h
        return self._out(h)


class GIKT(BaseKT):
    reproduction_metadata = {
        "family": "graph_interaction",
        "architecture": "Graph-enhanced interaction knowledge tracing",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.enc = InteractionEncoder(metadata, m["embedding_dim"], d, m["dropout"])
        self.graph = GraphEncoder(metadata, d, int(m.get("graph_layers", 2)), m["dropout"])
        layers = int(m.get("layers", 2))
        self.rnn = nn.GRU(d * 2, d, num_layers=layers, batch_first=True, dropout=m["dropout"] if layers > 1 else 0.0)
        self.gate = nn.Sequential(nn.Linear(d * 2, d), nn.Sigmoid())
        self.head = nn.Linear(d, 1)

    def forward(self, batch):
        x = self.enc(batch)
        g = self.graph(batch["item_id"], batch["concept_id"])
        recurrent, _ = self.rnn(torch.cat([x, g], dim=-1))
        gate = self.gate(torch.cat([recurrent, g], dim=-1))
        h = gate * recurrent + (1 - gate) * g
        return self._out(h)


class _SimpleKTBlock(nn.Module):
    def __init__(self, d: int, heads: int, dropout: float):
        super().__init__()
        self.attn = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d)
        self.ffn = nn.Sequential(nn.Linear(d, d * 2), nn.ReLU(), nn.Dropout(dropout), nn.Linear(d * 2, d))
        self.norm2 = nn.LayerNorm(d)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        z, _ = self.attn(x, x, x, attn_mask=causal_mask(x.size(1), x.device), key_padding_mask=~mask, need_weights=False)
        h = self.norm1(x + self.dropout(z))
        return self.norm2(h + self.dropout(self.ffn(h)))


class SimpleKT(BaseKT):
    """A compact KT-specific attention model with item difficulty modulation.

    The implementation stays deliberately simpler than the generic Transformer:
    question/concept embeddings, response-conditioned interaction embeddings,
    a trainable item-difficulty scalar, and compact causal attention blocks.
    """

    reproduction_metadata = {
        "family": "simple_attention",
        "architecture": "Compact KT-specific attention with item-difficulty modulation",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        m = cfg["model"]
        d = int(m["hidden_dim"])
        self.item = nn.Embedding(metadata["num_items"], d, padding_idx=0)
        self.concept = nn.Embedding(metadata["num_concepts"], d, padding_idx=0)
        self.response = nn.Embedding(2, d)
        self.item_difficulty = nn.Embedding(metadata["num_items"], 1, padding_idx=0)
        self.difficulty_direction = nn.Parameter(torch.zeros(d))
        self.pos = PositionalEncoding(d)
        self.blocks = nn.ModuleList(
            [_SimpleKTBlock(d, int(m.get("heads", 8)), float(m["dropout"])) for _ in range(int(m.get("layers", 2)))]
        )
        self.head = nn.Linear(d * 2, 1)

    def forward(self, batch):
        q = self.item(batch["item_id"]) + self.concept(batch["concept_id"])
        q = q + self.item_difficulty(batch["item_id"]) * self.difficulty_direction.view(1, 1, -1)
        x = self.pos(q + self.response(batch["response"].long().clamp(0, 1)))
        for block in self.blocks:
            x = block(x, batch["mask"])
        h = torch.cat([x, q], dim=-1)
        return {"logits": self.head(h).squeeze(-1), "hidden": x}
