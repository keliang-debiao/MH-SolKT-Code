from __future__ import annotations

import torch
from torch import nn

from .components import InteractionEncoder, GraphEncoder, StackedSelectiveStateSpaceFallback, OfficialMambaAdapter


class MHSolKT(nn.Module):
    """Mamba-style Hybrid Solfege Knowledge Tracing framework.

    The sequence depth is explicit and actually used by both the SSM branch and
    the causal LSTM branch. Auxiliary mastery and uncertainty heads share the
    fused representation and can be trained with low-weight diagnostic losses;
    the primary objective remains next-response BCE.
    """

    reproduction_metadata = {
        "family": "proposed_hybrid",
        "architecture": "Music-aware encoder + SSM branch + causal LSTM branch + graph interface",
        "distinct_implementation": True,
    }

    def __init__(self, metadata: dict, cfg: dict):
        super().__init__()
        mcfg = cfg["model"]
        hidden = int(mcfg["hidden_dim"])
        embed = int(mcfg.get("embedding_dim", 128))
        dropout = float(mcfg.get("dropout", 0.2))
        ssm_layers = int(mcfg.get("ssm_layers", mcfg.get("mamba_layers", 1)))
        lstm_layers = int(mcfg.get("lstm_layers", 1))

        self.use_ssm = bool(mcfg.get("use_ssm", True))
        self.use_lstm = bool(mcfg.get("use_lstm", True))
        self.use_graph = bool(mcfg.get("use_graph", True))
        self.use_mastery = bool(mcfg.get("use_mastery_head", True))
        self.use_uncertainty = bool(mcfg.get("use_uncertainty_head", True))

        self.encoder = InteractionEncoder(metadata, embed, hidden, dropout)
        if self.use_ssm:
            impl = mcfg.get("mamba_impl", "fallback")
            self.ssm = (
                OfficialMambaAdapter(hidden, ssm_layers)
                if impl == "official"
                else StackedSelectiveStateSpaceFallback(hidden, ssm_layers, dropout)
            )
        else:
            self.ssm = None

        self.lstm = (
            nn.LSTM(
                hidden,
                hidden,
                num_layers=lstm_layers,
                batch_first=True,
                dropout=dropout if lstm_layers > 1 else 0.0,
            )
            if self.use_lstm
            else None
        )
        self.graph = GraphEncoder(metadata, hidden, int(mcfg.get("graph_layers", 2)), dropout) if self.use_graph else None

        branches = int(self.use_ssm) + int(self.use_lstm) + int(self.use_graph)
        if branches == 0:
            raise ValueError("At least one MH-SolKT branch must be enabled.")
        self.fusion = nn.Sequential(
            nn.Linear(branches * hidden, hidden),
            nn.LayerNorm(hidden),
            nn.Dropout(dropout),
        )
        self.prediction_head = nn.Linear(hidden, 1)
        self.mastery_head = nn.Linear(hidden, 1) if self.use_mastery else None
        self.uncertainty_head = nn.Linear(hidden, 1) if self.use_uncertainty else None

        self.reproduction_metadata = {
            **self.reproduction_metadata,
            "hidden_dim": hidden,
            "embedding_dim": embed,
            "ssm_layers": ssm_layers if self.use_ssm else 0,
            "lstm_layers": lstm_layers if self.use_lstm else 0,
            "graph_layers": int(mcfg.get("graph_layers", 2)) if self.use_graph else 0,
            "mamba_impl": mcfg.get("mamba_impl", "fallback"),
            "use_mastery_head": self.use_mastery,
            "use_uncertainty_head": self.use_uncertainty,
        }

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        x = self.encoder(batch)
        parts = []
        if self.ssm is not None:
            parts.append(self.ssm(x))
        if self.lstm is not None:
            r, _ = self.lstm(x)
            parts.append(r)
        if self.graph is not None:
            parts.append(self.graph(batch["item_id"], batch["concept_id"]))
        fused = self.fusion(torch.cat(parts, dim=-1))
        out = {"logits": self.prediction_head(fused).squeeze(-1), "hidden": fused}
        if self.mastery_head is not None:
            out["mastery_logits"] = self.mastery_head(fused).squeeze(-1)
        if self.uncertainty_head is not None:
            out["uncertainty"] = torch.sigmoid(self.uncertainty_head(fused).squeeze(-1))
        return out
