from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any
import json
import yaml


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        if path.suffix.lower() in {".yaml", ".yml"}:
            cfg = yaml.safe_load(f)
        elif path.suffix.lower() == ".json":
            cfg = json.load(f)
        else:
            raise ValueError(f"Unsupported config format: {path.suffix}")
    if not isinstance(cfg, dict):
        raise TypeError("Configuration root must be a mapping.")
    return cfg


def deep_update(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_update(out[key], value)
        else:
            out[key] = deepcopy(value)
    return out


def save_config(cfg: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)
