from __future__ import annotations

import torch
import torch.nn.functional as F


def focal_bce_with_logits(logits: torch.Tensor, targets: torch.Tensor, gamma: float = 2.0) -> torch.Tensor:
    bce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    prob = torch.sigmoid(logits)
    pt = torch.where(targets > 0.5, prob, 1 - prob)
    return ((1 - pt).pow(gamma) * bce).mean()


def historical_concept_accuracy_target(inputs: dict[str, torch.Tensor]) -> torch.Tensor:
    """Construct a leakage-free concept-level mastery proxy from interaction history.

    For every valid position, the target is the cumulative accuracy for the same
    concept up to and including the current historical interaction. No future
    response is used. The proxy is used only as a low-weight diagnostic
    regularizer for the mastery head.
    """
    concept = inputs["concept_id"]
    response = inputs["response"].float()
    mask = inputs["mask"]
    target = torch.zeros_like(response)
    for b in range(response.size(0)):
        sums: dict[int, float] = {}
        counts: dict[int, int] = {}
        for t in range(response.size(1)):
            if not bool(mask[b, t]):
                continue
            cid = int(concept[b, t].item())
            sums[cid] = sums.get(cid, 0.0) + float(response[b, t].item())
            counts[cid] = counts.get(cid, 0) + 1
            target[b, t] = sums[cid] / counts[cid]
    return target


def compute_loss(
    outputs: dict[str, torch.Tensor],
    targets: torch.Tensor,
    valid: torch.Tensor,
    cfg: dict,
    inputs: dict[str, torch.Tensor] | None = None,
) -> torch.Tensor:
    logits = outputs["logits"][valid]
    y = targets[valid]
    lcfg = cfg.get("loss", {})
    kind = lcfg.get("type", "bce")
    if kind == "focal":
        loss = focal_bce_with_logits(logits, y, float(lcfg.get("focal_gamma", 2.0)))
    else:
        smoothing = float(lcfg.get("label_smoothing", 0.0))
        y_for_bce = y * (1 - smoothing) + 0.5 * smoothing if smoothing > 0 else y
        loss = F.binary_cross_entropy_with_logits(logits, y_for_bce)

    if float(lcfg.get("brier_weight", 0.0)) > 0:
        p = torch.sigmoid(logits)
        loss = loss + float(lcfg["brier_weight"]) * ((p - y) ** 2).mean()

    # The primary objective remains next-response BCE. These low-weight terms
    # train the diagnostic interfaces and regularize the shared fused state.
    uncertainty_weight = float(lcfg.get("uncertainty_weight", 0.0))
    if "uncertainty" in outputs and uncertainty_weight > 0:
        with torch.no_grad():
            error = (torch.sigmoid(outputs["logits"])[valid] - targets[valid]).abs()
        u = outputs["uncertainty"][valid].clamp(1e-6, 1 - 1e-6)
        loss = loss + uncertainty_weight * F.mse_loss(u, error)

    mastery_weight = float(lcfg.get("mastery_weight", 0.0))
    if "mastery_logits" in outputs and mastery_weight > 0:
        if inputs is None:
            raise ValueError("inputs are required when mastery_weight > 0")
        mastery_target = historical_concept_accuracy_target(inputs)
        m = outputs["mastery_logits"][valid]
        loss = loss + mastery_weight * F.binary_cross_entropy_with_logits(m, mastery_target[valid])
    return loss
