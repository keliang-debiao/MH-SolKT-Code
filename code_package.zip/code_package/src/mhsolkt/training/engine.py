from __future__ import annotations

from pathlib import Path
from typing import Any
import time
import numpy as np
import pandas as pd
import torch
from torch.optim import AdamW
import matplotlib.pyplot as plt

from .losses import compute_loss
from .checkpoint import save_checkpoint, load_checkpoint
from mhsolkt.evaluation.metrics import binary_metrics
from mhsolkt.utils.io import ensure_dir, write_json, environment_manifest


def to_device(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {k: v.to(device) for k, v in batch.items()}


def next_response_view(batch: dict[str, torch.Tensor]) -> tuple[dict[str, torch.Tensor], torch.Tensor, torch.Tensor]:
    inputs = {k: v[:, :-1] for k, v in batch.items()}
    targets = batch["response"][:, 1:]
    valid = batch["mask"][:, :-1] & batch["mask"][:, 1:]
    return inputs, targets, valid


def predict(model, loader, device: torch.device) -> dict[str, np.ndarray]:
    model.eval()
    ys, ps, us, ms = [], [], [], []
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, device)
            inputs, targets, valid = next_response_view(batch)
            outputs = model(inputs)
            prob = torch.sigmoid(outputs["logits"])
            ys.append(targets[valid].cpu().numpy())
            ps.append(prob[valid].cpu().numpy())
            if "uncertainty" in outputs:
                us.append(outputs["uncertainty"][valid].cpu().numpy())
            if "mastery_logits" in outputs:
                ms.append(torch.sigmoid(outputs["mastery_logits"])[valid].cpu().numpy())
    result = {"y_true": np.concatenate(ys), "prob": np.concatenate(ps)}
    if us:
        result["uncertainty"] = np.concatenate(us)
    if ms:
        result["mastery"] = np.concatenate(ms)
    return result


def train_one_run(model, train_loader, val_loader, test_loader, cfg: dict[str, Any], device: torch.device, run_dir: str | Path) -> dict[str, Any]:
    run_dir = ensure_dir(run_dir)
    env = environment_manifest()
    write_json(env, run_dir / "environment.json")
    (run_dir / "pip_freeze.txt").write_text("\n".join(env.get("pip_freeze", [])) + "\n", encoding="utf-8")
    write_json(cfg, run_dir / "resolved_config.json")

    tcfg = cfg["training"]
    optimizer = AdamW(model.parameters(), lr=float(tcfg["learning_rate"]), weight_decay=float(tcfg["weight_decay"]))
    best_auc = -float("inf")
    best_epoch = -1
    patience = int(tcfg["patience"])
    wait = 0
    history = []
    checkpoint_path = run_dir / "best_checkpoint.pt"

    model.to(device)
    for epoch in range(1, int(tcfg["epochs"]) + 1):
        model.train()
        start = time.perf_counter()
        total_loss = 0.0
        total_count = 0
        for batch in train_loader:
            batch = to_device(batch, device)
            inputs, targets, valid = next_response_view(batch)
            optimizer.zero_grad(set_to_none=True)
            outputs = model(inputs)
            loss = compute_loss(outputs, targets, valid, cfg, inputs=inputs)
            loss.backward()
            if float(tcfg.get("grad_clip", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(tcfg["grad_clip"]))
            optimizer.step()
            total_loss += float(loss.detach().cpu()) * int(valid.sum().item())
            total_count += int(valid.sum().item())
        epoch_seconds = time.perf_counter() - start
        val_pred = predict(model, val_loader, device)
        val_metrics = binary_metrics(val_pred["y_true"], val_pred["prob"], ece_bins=int(cfg["evaluation"].get("ece_bins", 15)))
        row = {
            "epoch": epoch,
            "train_loss": total_loss / max(total_count, 1),
            "validation_auc": val_metrics["auc"],
            "validation_logloss": val_metrics["logloss"],
            "validation_ece": val_metrics["ece"],
            "epoch_seconds": epoch_seconds,
        }
        history.append(row)
        if val_metrics["auc"] > best_auc:
            best_auc = val_metrics["auc"]
            best_epoch = epoch
            wait = 0
            save_checkpoint(model, optimizer, epoch, best_auc, checkpoint_path)
        else:
            wait += 1
            if wait >= patience:
                break

    history_df = pd.DataFrame(history)
    history_df.to_csv(run_dir / "training_history.csv", index=False)
    history_df[["epoch", "validation_auc"]].to_csv(run_dir / "validation_auc_history.csv", index=False)

    # Training-curve artifact required for reviewer audit. The figure is generated only after a real run.
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(history_df["epoch"], history_df["validation_auc"], marker="o", markersize=3)
    ax.set_xlabel("Training epoch")
    ax.set_ylabel("Validation AUC")
    fig.tight_layout()
    fig.savefig(run_dir / "training_curve.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    ckpt = load_checkpoint(model, checkpoint_path, device)
    val_pred = predict(model, val_loader, device)
    val_metrics = binary_metrics(val_pred["y_true"], val_pred["prob"], ece_bins=int(cfg["evaluation"].get("ece_bins", 15)))
    write_json({
        "selected_epoch": int(ckpt["epoch"]),
        "selected_validation_auc": float(ckpt["validation_auc"]),
        "early_stopping_epoch": int(history[-1]["epoch"]),
        "patience": patience,
    }, run_dir / "checkpoint_metadata.json")
    write_json(val_metrics, run_dir / "validation_selection_metrics.json")
    np.savez_compressed(run_dir / "validation_predictions.npz", **val_pred)

    evaluate_test = bool(cfg.get("evaluation", {}).get("evaluate_test", True))
    if not evaluate_test:
        return {"validation_metrics": val_metrics, "best_epoch": best_epoch, "best_validation_auc": best_auc, "run_dir": str(run_dir)}

    test_pred = predict(model, test_loader, device)
    test_metrics = binary_metrics(test_pred["y_true"], test_pred["prob"], ece_bins=int(cfg["evaluation"].get("ece_bins", 15)))
    write_json(test_metrics, run_dir / "final_test_metrics.json")
    np.savez_compressed(run_dir / "test_predictions.npz", **test_pred)
    return {"metrics": test_metrics, "best_epoch": best_epoch, "best_validation_auc": best_auc, "run_dir": str(run_dir)}
