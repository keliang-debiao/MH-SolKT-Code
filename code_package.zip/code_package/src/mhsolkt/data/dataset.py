from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable
import json
import torch
from torch.utils.data import Dataset, DataLoader


def make_windows(sequences: list[dict[str, Any]], max_len: int, indices: Iterable[int] | None = None) -> list[dict[str, Any]]:
    if indices is None:
        indices = range(len(sequences))
    windows: list[dict[str, Any]] = []
    for idx in indices:
        seq = sequences[idx]
        n = len(seq["response"])
        if n < 2:
            continue
        start = 0
        while start < n - 1:
            end = min(start + max_len, n)
            piece = {k: (v[start:end] if isinstance(v, list) else v) for k, v in seq.items()}
            windows.append(piece)
            if end == n:
                break
            start = end - 1
    return windows


class SequenceWindowDataset(Dataset):
    def __init__(self, windows: list[dict[str, Any]]):
        self.windows = windows

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return self.windows[idx]


def collate_windows(batch: list[dict[str, Any]]) -> dict[str, torch.Tensor]:
    max_len = max(len(x["response"]) for x in batch)
    aux_dim = max((len(x["aux"][0]) if x["aux"] else 0) for x in batch)
    b = len(batch)
    out = {
        "item_id": torch.zeros(b, max_len, dtype=torch.long),
        "concept_id": torch.zeros(b, max_len, dtype=torch.long),
        "score_id": torch.zeros(b, max_len, dtype=torch.long),
        "response": torch.zeros(b, max_len, dtype=torch.float32),
        "mask": torch.zeros(b, max_len, dtype=torch.bool),
        "aux": torch.zeros(b, max_len, aux_dim, dtype=torch.float32),
    }
    for i, x in enumerate(batch):
        n = len(x["response"])
        out["item_id"][i, :n] = torch.tensor(x["item_id"], dtype=torch.long)
        out["concept_id"][i, :n] = torch.tensor(x["concept_id"], dtype=torch.long)
        out["score_id"][i, :n] = torch.tensor(x["score_id"], dtype=torch.long)
        out["response"][i, :n] = torch.tensor(x["response"], dtype=torch.float32)
        out["mask"][i, :n] = True
        if aux_dim:
            aux = torch.tensor(x["aux"], dtype=torch.float32)
            out["aux"][i, :n, :aux.shape[-1]] = aux
    return out


def load_sequences(processed_dir: str | Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    processed_dir = Path(processed_dir)
    sequences = torch.load(processed_dir / "sequences.pt", map_location="cpu")
    with (processed_dir / "metadata.json").open("r", encoding="utf-8") as f:
        metadata = json.load(f)
    return sequences, metadata


def build_loaders(cfg: dict[str, Any], manifest_path: str | Path) -> tuple[DataLoader, DataLoader, DataLoader, dict[str, Any]]:
    sequences, metadata = load_sequences(cfg["data"]["processed_dir"])
    with Path(manifest_path).open("r", encoding="utf-8") as f:
        manifest = json.load(f)
    max_len = int(cfg["training"]["max_sequence_length"])
    if manifest["strategy"] == "interaction_window_random":
        all_windows = make_windows(sequences, max_len)
        train_w = [all_windows[i] for i in manifest["train_window_indices"]]
        val_w = [all_windows[i] for i in manifest["val_window_indices"]]
        test_w = [all_windows[i] for i in manifest["test_window_indices"]]
    else:
        train_w = make_windows(sequences, max_len, manifest["train_indices"])
        val_w = make_windows(sequences, max_len, manifest["val_indices"])
        test_w = make_windows(sequences, max_len, manifest["test_indices"])

    batch_size = int(cfg["training"]["batch_size"])
    workers = int(cfg["training"].get("num_workers", 0))
    # Use a dedicated loader generator so model construction cannot change batch order.
    # This is essential for fair ablations: adding/removing diagnostic heads must not
    # alter the training sequence merely by consuming global RNG state.
    generator = torch.Generator()
    generator.manual_seed(int(cfg["experiment"]["seed"]))
    train = DataLoader(
        SequenceWindowDataset(train_w), batch_size=batch_size, shuffle=True,
        num_workers=workers, collate_fn=collate_windows, generator=generator
    )
    val = DataLoader(SequenceWindowDataset(val_w), batch_size=batch_size, shuffle=False, num_workers=workers, collate_fn=collate_windows)
    test = DataLoader(SequenceWindowDataset(test_w), batch_size=batch_size, shuffle=False, num_workers=workers, collate_fn=collate_windows)
    return train, val, test, metadata
