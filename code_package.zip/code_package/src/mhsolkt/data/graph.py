from __future__ import annotations

import torch


def build_bipartite_adjacency(num_items: int, num_concepts: int, edges: list[list[int]]) -> torch.Tensor:
    n = num_items + num_concepts
    adj = torch.zeros(n, n, dtype=torch.float32)
    for item, concept in edges:
        ci = num_items + int(concept)
        ii = int(item)
        if 0 <= ii < num_items and 0 <= ci < n:
            adj[ii, ci] = 1.0
            adj[ci, ii] = 1.0
    adj.fill_diagonal_(1.0)
    deg = adj.sum(dim=1).clamp_min(1.0)
    inv = deg.pow(-0.5)
    return inv[:, None] * adj * inv[None, :]
