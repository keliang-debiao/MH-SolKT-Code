from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import torch


def create_toy_dataset(processed_dir: str | Path, seed: int = 123, students: int = 32, length: int = 48) -> None:
    rng = np.random.default_rng(seed)
    processed_dir = Path(processed_dir)
    processed_dir.mkdir(parents=True, exist_ok=True)
    sequences = []
    edges = set()
    for sid in range(1, students + 1):
        concepts = rng.integers(1, 9, size=length)
        items = concepts * 4 + rng.integers(0, 4, size=length) + 1
        scores = rng.integers(1, 6, size=length)
        mastery = 1 / (1 + np.exp(-(np.linspace(-1, 1, length) + rng.normal(0, 0.25, length))))
        response = (rng.random(length) < mastery).astype(int)
        for i, c in zip(items, concepts):
            edges.add((int(i), int(c)))
        sequences.append({
            "student_id": sid,
            "item_id": items.astype(int).tolist(),
            "concept_id": concepts.astype(int).tolist(),
            "score_id": scores.astype(int).tolist(),
            "response": response.astype(int).tolist(),
            "timestamp": list(range(length)),
            "aux": [[float(t / max(length - 1, 1))] for t in range(length)],
        })
    metadata = {
        "num_students": students + 1,
        "num_items": max(max(s["item_id"]) for s in sequences) + 1,
        "num_concepts": 10,
        "num_scores": 7,
        "aux_dim": 1,
        "auxiliary_columns": ["toy_progress"],
        "item_concept_edges": [list(x) for x in sorted(edges)],
    }
    torch.save(sequences, processed_dir / "sequences.pt")
    with (processed_dir / "metadata.json").open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
