from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import math
import numpy as np
import torch


def _save(obj: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def make_student_wise_manifest(sequences_path: str | Path, out_path: str | Path, seed: int, ratios=(0.7, 0.15, 0.15)) -> dict[str, Any]:
    seqs = torch.load(sequences_path, map_location="cpu")
    ids = np.arange(len(seqs))
    rng = np.random.default_rng(seed)
    rng.shuffle(ids)
    n = len(ids)
    n_train = int(round(n * ratios[0]))
    n_val = int(round(n * ratios[1]))
    manifest = {
        "strategy": "student_wise",
        "seed": seed,
        "train_indices": ids[:n_train].tolist(),
        "val_indices": ids[n_train:n_train + n_val].tolist(),
        "test_indices": ids[n_train + n_val:].tolist(),
    }
    _save(manifest, Path(out_path))
    return manifest


def make_interaction_window_manifest(num_windows: int, out_path: str | Path, seed: int, ratios=(0.7, 0.15, 0.15)) -> dict[str, Any]:
    ids = np.arange(num_windows)
    rng = np.random.default_rng(seed)
    rng.shuffle(ids)
    n = len(ids)
    n_train = int(round(n * ratios[0]))
    n_val = int(round(n * ratios[1]))
    manifest = {
        "strategy": "interaction_window_random",
        "seed": seed,
        "train_window_indices": ids[:n_train].tolist(),
        "val_window_indices": ids[n_train:n_train+n_val].tolist(),
        "test_window_indices": ids[n_train+n_val:].tolist(),
    }
    _save(manifest, Path(out_path))
    return manifest


def make_student_fivefold_manifests(sequences_path: str | Path, out_dir: str | Path, seed: int, folds: int = 5) -> list[Path]:
    seqs = torch.load(sequences_path, map_location="cpu")
    ids = np.arange(len(seqs))
    rng = np.random.default_rng(seed)
    rng.shuffle(ids)
    fold_ids = np.array_split(ids, folds)
    paths = []
    out_dir = Path(out_dir)
    for fold in range(folds):
        test = fold_ids[fold]
        val = fold_ids[(fold + 1) % folds]
        train = np.concatenate([fold_ids[i] for i in range(folds) if i not in {fold, (fold + 1) % folds}])
        path = out_dir / f"fold_{fold}.json"
        _save({
            "strategy": "student_wise_fivefold",
            "seed": seed,
            "fold": fold,
            "train_indices": train.tolist(),
            "val_indices": val.tolist(),
            "test_indices": test.tolist(),
        }, path)
        paths.append(path)
    return paths


def make_cold_start_manifest(sequences_path: str | Path, base_manifest_path: str | Path, out_path: str | Path, quantile: float = 0.25) -> dict[str, Any]:
    seqs = torch.load(sequences_path, map_location="cpu")
    with Path(base_manifest_path).open("r", encoding="utf-8") as f:
        base = json.load(f)
    test = base["test_indices"]
    lengths = np.array([len(seqs[i]["response"]) for i in test])
    threshold = float(np.quantile(lengths, quantile))
    cold = [i for i in test if len(seqs[i]["response"]) <= threshold]
    manifest = {
        "strategy": "cold_start_student_subset",
        "base_manifest": str(base_manifest_path),
        "quantile": quantile,
        "train_indices": base["train_indices"],
        "val_indices": base["val_indices"],
        "test_indices": cold,
    }
    _save(manifest, Path(out_path))
    return manifest


def assert_no_student_overlap(manifest: dict[str, Any]) -> None:
    train = set(manifest.get("train_indices", []))
    val = set(manifest.get("val_indices", []))
    test = set(manifest.get("test_indices", []))
    if train & val or train & test or val & test:
        raise AssertionError("Student-wise split contains overlap.")
