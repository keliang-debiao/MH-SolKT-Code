from __future__ import annotations

REQUIRED_CANONICAL_COLUMNS = [
    "student_id",
    "item_id",
    "concept_id",
    "score_id",
    "timestamp",
    "correct",
]

OPTIONAL_CANONICAL_COLUMNS = [
    "time_feature",
    "difficulty_feature",
    "statistical_feature",
]
