from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any
import json
import pandas as pd
import torch

from .schema import REQUIRED_CANONICAL_COLUMNS


def _read_table(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported raw dataset format: {suffix}")


def _factorize(series: pd.Series) -> tuple[pd.Series, dict[str, int]]:
    values = series.astype(str)
    uniques = sorted(values.unique().tolist())
    mapping = {value: idx + 1 for idx, value in enumerate(uniques)}
    return values.map(mapping).astype("int64"), mapping


def preprocess_dataset(cfg: dict[str, Any]) -> dict[str, Any]:
    raw_path = Path(cfg["data"]["raw_path"])
    processed_dir = Path(cfg["data"]["processed_dir"])
    processed_dir.mkdir(parents=True, exist_ok=True)

    df = _read_table(raw_path)
    column_map = cfg["data"].get("column_map", {})
    rename = {source: target for target, source in column_map.items() if source in df.columns}
    df = df.rename(columns=rename)

    missing = [c for c in REQUIRED_CANONICAL_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns after mapping: {missing}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    if df["timestamp"].isna().any():
        df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["student_id", "item_id", "concept_id", "score_id", "timestamp", "correct"])
    df["correct"] = (pd.to_numeric(df["correct"], errors="coerce") > 0).astype("int64")

    mappings: dict[str, dict[str, int]] = {}
    for col in ["student_id", "item_id", "concept_id", "score_id"]:
        df[col], mappings[col] = _factorize(df[col])

    aux_cols = cfg["data"].get("auxiliary_columns", [])
    for col in aux_cols:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0).astype("float32")

    df = df.sort_values(["student_id", "timestamp"], kind="mergesort").reset_index(drop=True)

    sequences = []
    item_concept_pairs = set()
    for sid, group in df.groupby("student_id", sort=False):
        items = group["item_id"].astype(int).tolist()
        concepts = group["concept_id"].astype(int).tolist()
        for i, c in zip(items, concepts):
            item_concept_pairs.add((i, c))
        sequences.append({
            "student_id": int(sid),
            "item_id": items,
            "concept_id": concepts,
            "score_id": group["score_id"].astype(int).tolist(),
            "response": group["correct"].astype(int).tolist(),
            "timestamp": group["timestamp"].astype(str).tolist(),
            "aux": group[aux_cols].astype(float).values.tolist() if aux_cols else [[] for _ in range(len(group))],
        })

    metadata = {
        "num_students": len(mappings["student_id"]) + 1,
        "num_items": len(mappings["item_id"]) + 1,
        "num_concepts": len(mappings["concept_id"]) + 1,
        "num_scores": len(mappings["score_id"]) + 1,
        "aux_dim": len(aux_cols),
        "auxiliary_columns": aux_cols,
        "item_concept_edges": sorted([list(p) for p in item_concept_pairs]),
    }

    torch.save(sequences, processed_dir / "sequences.pt")
    with (processed_dir / "metadata.json").open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    with (processed_dir / "id_mappings.json").open("w", encoding="utf-8") as f:
        json.dump(mappings, f, indent=2, ensure_ascii=False)
    return metadata
