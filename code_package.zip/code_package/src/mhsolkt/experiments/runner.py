from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import shutil

from mhsolkt.config import load_config, deep_update
from mhsolkt.data.dataset import build_loaders
from mhsolkt.models.registry import build_model
from mhsolkt.training.engine import train_one_run
from mhsolkt.utils.device import resolve_device
from mhsolkt.utils.io import write_json
from mhsolkt.utils.seed import seed_everything


def resolve_config(common_path: str | Path, experiment_path: str | Path, seed: int | None = None) -> dict[str, Any]:
    cfg = deep_update(load_config(common_path), load_config(experiment_path))
    if seed is not None:
        cfg["experiment"]["seed"] = int(seed)
    return cfg


def _infer_family(run_dir: Path) -> str:
    parts = run_dir.parts
    if "outputs" in parts:
        idx = parts.index("outputs")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    return run_dir.parts[0] if run_dir.parts else "unknown"


def _fold_from_path(run_dir: Path) -> int | None:
    for part in run_dir.parts:
        match = re.fullmatch(r"fold_(\d+)", part)
        if match:
            return int(match.group(1))
    return None


def run_experiment(cfg: dict[str, Any], manifest_path: str | Path, run_dir: str | Path) -> dict[str, Any]:
    seed = int(cfg["experiment"]["seed"])
    seed_everything(seed, deterministic=bool(cfg["training"].get("deterministic", True)))
    device = resolve_device(cfg["training"].get("device", "auto"))
    manifest_path = Path(manifest_path)
    run_dir = Path(run_dir)
    with manifest_path.open("r", encoding="utf-8") as f:
        split_manifest = json.load(f)
    train_loader, val_loader, test_loader, metadata = build_loaders(cfg, manifest_path)
    model = build_model(metadata, cfg)

    run_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(manifest_path, run_dir / "split_manifest.json")
    run_metadata = {
        "family": cfg["experiment"].get("family", _infer_family(run_dir)),
        "configuration_name": cfg["experiment"]["name"],
        "model_name": cfg["model"]["name"],
        "seed": seed,
        "protocol": cfg["experiment"].get("protocol", split_manifest.get("strategy")),
        "fold": cfg["experiment"].get("fold", _fold_from_path(run_dir)),
        "manifest_path": str(manifest_path),
        "run_dir": str(run_dir),
    }
    write_json(run_metadata, run_dir / "run_metadata.json")
    write_json(getattr(model, "reproduction_metadata", {}), run_dir / "model_provenance.json")
    return train_one_run(model, train_loader, val_loader, test_loader, cfg, device, run_dir)


def run_config_file(
    common_path: str | Path,
    experiment_path: str | Path,
    manifest_template: str,
    output_root: str | Path,
    seeds: list[int],
) -> list[dict[str, Any]]:
    results = []
    exp_cfg = load_config(experiment_path)
    exp_name = exp_cfg["experiment"]["name"]
    for seed in seeds:
        cfg = resolve_config(common_path, experiment_path, seed)
        manifest = manifest_template.format(seed=seed)
        run_dir = Path(output_root) / exp_name / f"seed_{seed}"
        results.append(run_experiment(cfg, manifest, run_dir))
    return results
