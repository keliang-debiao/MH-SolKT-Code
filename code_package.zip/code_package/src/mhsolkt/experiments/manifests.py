from __future__ import annotations

from pathlib import Path
from typing import Any
import json


def load_manifest(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)


def iter_jobs(path: str | Path):
    manifest = load_manifest(path)
    for family in manifest["families"]:
        for config in family["configs"]:
            yield family["name"], config
