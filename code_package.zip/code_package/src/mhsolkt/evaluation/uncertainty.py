from __future__ import annotations

import numpy as np
from scipy.stats import pearsonr
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score


def predictive_entropy(prob: np.ndarray) -> np.ndarray:
    p = np.clip(prob, 1e-7, 1 - 1e-7)
    return -(p * np.log(p) + (1 - p) * np.log(1 - p))


def inverse_max_probability(prob: np.ndarray) -> np.ndarray:
    return 1.0 - np.maximum(prob, 1.0 - prob)


def risk_coverage_aurc(y_true: np.ndarray, prob: np.ndarray, uncertainty: np.ndarray) -> float:
    error = ((prob >= 0.5).astype(int) != y_true.astype(int)).astype(float)
    order = np.argsort(uncertainty)
    err = error[order]
    cumulative_risk = np.cumsum(err) / np.arange(1, len(err) + 1)
    coverage = np.arange(1, len(err) + 1) / len(err)
    return float(np.trapz(cumulative_risk, coverage))


def uncertainty_metrics(y_true: np.ndarray, prob: np.ndarray, score: np.ndarray) -> dict[str, float]:
    error = ((prob >= 0.5).astype(int) != y_true.astype(int)).astype(int)
    corr = pearsonr(score, error).statistic if np.std(score) > 0 and np.std(error) > 0 else float("nan")
    return {
        "mean_uncertainty": float(np.mean(score)),
        "error_correlation": float(corr),
        "error_auroc": float(roc_auc_score(error, score)) if len(np.unique(error)) > 1 else float("nan"),
        "error_auprc": float(average_precision_score(error, score)) if len(np.unique(error)) > 1 else float("nan"),
        "aurc": risk_coverage_aurc(y_true, prob, score),
    }


def fit_calibration_aware_uncertainty(val_y: np.ndarray, val_prob: np.ndarray, val_raw: np.ndarray | None = None):
    feats = [predictive_entropy(val_prob), inverse_max_probability(val_prob)]
    if val_raw is not None:
        feats.append(val_raw)
    x = np.column_stack(feats)
    error = ((val_prob >= 0.5).astype(int) != val_y.astype(int)).astype(int)
    clf = LogisticRegression(max_iter=1000)
    clf.fit(x, error)
    return clf


def calibration_aware_score(model, prob: np.ndarray, raw: np.ndarray | None = None) -> np.ndarray:
    feats = [predictive_entropy(prob), inverse_max_probability(prob)]
    if raw is not None:
        feats.append(raw)
    return model.predict_proba(np.column_stack(feats))[:, 1]
