from __future__ import annotations

import numpy as np
from sklearn.metrics import ndcg_score


def top_risk_metrics(y_true: np.ndarray, prob: np.ndarray, budgets=(0.05, 0.10, 0.20), ndcg_budget: float = 0.10) -> dict[str, float]:
    risk = 1.0 - prob
    error = (1 - y_true.astype(int)).astype(int)
    order = np.argsort(-risk)
    total_errors = max(int(error.sum()), 1)
    out: dict[str, float] = {}
    for budget in budgets:
        k = max(1, int(round(len(error) * budget)))
        chosen = error[order[:k]]
        label = int(round(budget * 100))
        out[f"precision_at_{label}pct"] = float(chosen.mean())
        out[f"recall_at_{label}pct"] = float(chosen.sum() / total_errors)
    k = max(1, int(round(len(error) * ndcg_budget)))
    out[f"ndcg_at_{int(round(ndcg_budget * 100))}pct"] = float(ndcg_score(error.reshape(1, -1), risk.reshape(1, -1), k=k))
    return out
