from __future__ import annotations

import time
import torch

from mhsolkt.training.losses import compute_loss


def count_parameters(model) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def measure_epoch_runtime(model, loader, optimizer, cfg: dict, device: torch.device, warmup_batches: int = 2) -> float:
    """Measure a training epoch using the same configured objective as formal runs."""
    model.train()
    times = []
    for idx, batch in enumerate(loader):
        batch = {k: v.to(device) for k, v in batch.items()}
        inputs = {k: v[:, :-1] for k, v in batch.items()}
        targets = batch["response"][:, 1:]
        valid = batch["mask"][:, :-1] & batch["mask"][:, 1:]
        if device.type == "cuda":
            torch.cuda.synchronize()
        start = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        out = model(inputs)
        loss = compute_loss(out, targets, valid, cfg, inputs=inputs)
        loss.backward()
        optimizer.step()
        if device.type == "cuda":
            torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        if idx >= warmup_batches:
            times.append(elapsed)
    if not times:
        return float("nan")
    return float((sum(times) / len(times)) * len(loader))
