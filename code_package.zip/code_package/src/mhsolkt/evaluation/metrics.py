from __future__ import annotations

import numpy as np
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, log_loss, brier_score_loss, mean_squared_error


def expected_calibration_error(y_true: np.ndarray, prob: np.ndarray, bins: int = 15) -> float:
    y_true = np.asarray(y_true)
    prob = np.asarray(prob)
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (prob >= lo) & (prob < hi if hi < 1.0 else prob <= hi)
        if mask.any():
            confidence = prob[mask].mean()
            accuracy = y_true[mask].mean()
            ece += mask.mean() * abs(accuracy - confidence)
    return float(ece)


def binary_metrics(y_true: np.ndarray, prob: np.ndarray, threshold: float = 0.5, ece_bins: int = 15) -> dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    prob = np.asarray(prob).astype(float)
    pred = (prob >= threshold).astype(int)
    out = {
        "auc": float(roc_auc_score(y_true, prob)) if len(np.unique(y_true)) > 1 else float("nan"),
        "acc": float(accuracy_score(y_true, pred)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall": float(recall_score(y_true, pred, zero_division=0)),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "logloss": float(log_loss(y_true, np.clip(prob, 1e-7, 1 - 1e-7), labels=[0, 1])),
        "brier": float(brier_score_loss(y_true, prob)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, prob))),
        "ece": expected_calibration_error(y_true, prob, ece_bins),
    }
    return out
