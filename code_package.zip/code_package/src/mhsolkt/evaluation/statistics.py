from __future__ import annotations

import numpy as np
import pandas as pd


def sample_sd(values) -> float:
    return float(np.std(np.asarray(values, dtype=float), ddof=1))


def paired_summary(a, b) -> dict[str, float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.shape != b.shape:
        raise ValueError("Paired arrays must have identical shapes.")
    diff = a - b
    pooled_av = np.sqrt((np.var(a, ddof=1) + np.var(b, ddof=1)) / 2)
    return {
        "mean_delta": float(diff.mean()),
        "paired_sd": float(diff.std(ddof=1)),
        "cohens_d_av": float(diff.mean() / pooled_av) if pooled_av > 0 else float("nan"),
        "n": int(len(diff)),
    }


def collect_seed_metric(source_csv: str, metric: str = "auc") -> pd.DataFrame:
    df = pd.read_csv(source_csv)
    required = {"model", "seed", metric}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    return df[["model", "seed", metric]].copy()


def paired_table(source_csv: str, reference_model: str, metric: str = "auc") -> pd.DataFrame:
    df = collect_seed_metric(source_csv, metric)
    pivot = df.pivot(index="seed", columns="model", values=metric).sort_index()
    if reference_model not in pivot.columns:
        raise KeyError(reference_model)
    rows = []
    for model in pivot.columns:
        if model == reference_model:
            continue
        pair = pivot[[reference_model, model]].dropna()
        stats = paired_summary(pair[reference_model].values, pair[model].values)
        rows.append({"reference": reference_model, "comparison": model, **stats})
    return pd.DataFrame(rows)
