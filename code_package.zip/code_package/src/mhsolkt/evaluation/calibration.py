from __future__ import annotations

import numpy as np
import torch
from torch import nn


class TemperatureScaler(nn.Module):
    def __init__(self):
        super().__init__()
        self.log_temperature = nn.Parameter(torch.zeros(()))

    @property
    def temperature(self) -> torch.Tensor:
        return self.log_temperature.exp().clamp(1e-3, 100.0)

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits / self.temperature


def fit_temperature(prob: np.ndarray, y_true: np.ndarray, max_iter: int = 100) -> float:
    p = np.clip(prob, 1e-7, 1 - 1e-7)
    logits = torch.tensor(np.log(p / (1 - p)), dtype=torch.float32)
    y = torch.tensor(y_true, dtype=torch.float32)
    scaler = TemperatureScaler()
    optim = torch.optim.LBFGS(scaler.parameters(), lr=0.1, max_iter=max_iter)
    loss_fn = nn.BCEWithLogitsLoss()

    def closure():
        optim.zero_grad()
        loss = loss_fn(scaler(logits), y)
        loss.backward()
        return loss

    optim.step(closure)
    return float(scaler.temperature.detach())


def apply_temperature(prob: np.ndarray, temperature: float) -> np.ndarray:
    p = np.clip(prob, 1e-7, 1 - 1e-7)
    logits = np.log(p / (1 - p)) / temperature
    return 1 / (1 + np.exp(-logits))
