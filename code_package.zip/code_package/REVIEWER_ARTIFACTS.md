# Reviewer audit artifacts

This package contains the reproduction source code, exact configurations, per-seed logs, training histories, validation-AUC histories, selected-checkpoint metadata, final test metrics, aggregated seed-level source files, paired-statistics audit files, and reviewer-completeness checks for the experiments reported in the manuscript.

## Per formal run

- `run_metadata.json`
- `model_provenance.json`
- `split_manifest.json`
- `resolved_config.json`
- `environment.json`
- `pip_freeze.txt`
- `training_history.csv`
- `training_curve.png`
- `validation_auc_history.csv`
- `checkpoint_metadata.json`
- `validation_selection_metrics.json`
- `final_test_metrics.json`
- `validation_predictions.npz`
- `test_predictions.npz`

## Audit commands

```bash
python scripts/aggregate_all.py
python scripts/audit_seed_statistics.py
python scripts/verify_reviewer_completeness.py
python scripts/hash_reviewer_artifacts.py
```

The aggregation step creates one seed-level source file for the primary comparison and derives paired AUC statistics from that same source. The audit script independently recomputes the paired statistics. The completeness script verifies expected run counts and required files. The checksum file records artifact integrity.
