# Dataset interface

The raw SingPAD/SingKT data are not redistributed. Place an authorized CSV or Parquet file in `data/raw/` and edit `configs/common.yaml` so `data.raw_path` points to the file.

Required canonical fields after column mapping:

- `student_id`: learner identifier
- `item_id`: note-level item identifier
- `concept_id`: music-knowledge concept identifier
- `score_id`: score or music-piece identifier
- `timestamp`: chronological ordering field
- `correct`: binary response correctness

Optional auxiliary inputs are listed under `data.auxiliary_columns`. Missing optional columns are filled with zero so the pipeline remains executable; for formal reproduction, map the exact fields used in the authorized dataset.

The preprocessing script factorizes identifiers, sorts interactions by student and time, stores student-wise sequences, and exports item-concept edges for the graph interface.
