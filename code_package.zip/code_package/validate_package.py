from __future__ import annotations

from pathlib import Path
import ast
import compileall
import yaml

ROOT = Path(__file__).resolve().parent

EXPECTED = [
    "REVIEWER_ARTIFACTS.md",
    "REVIEWER_COMPLIANCE_MATRIX.md",
    "ARTIFACT_CONTRACT.md",
    "REPRODUCTION_CHECKLIST.md",
    "DATA_SCHEMA.md",
    "environment-primary.yml",
    "environment-official-mamba.yml",
    "configs/tuning_grids/baselines.yaml",
    "scripts/preprocess_singpad.py",
    "scripts/make_splits.py",
    "scripts/run_hyperparameter_search.py",
    "scripts/verify_tuning_selection.py",
    "scripts/run_primary.py",
    "scripts/run_ablations.py",
    "scripts/run_mamba_sensitivity.py",
    "scripts/check_official_mamba_environment.py",
    "scripts/run_hidden_length_sensitivity.py",
    "scripts/run_calibration.py",
    "scripts/run_uncertainty.py",
    "scripts/run_intervention.py",
    "scripts/run_protocol_robustness.py",
    "scripts/aggregate_protocol_fivefold.py",
    "scripts/run_efficiency.py",
    "scripts/run_training_trajectory.py",
    "scripts/run_smoke_toy.py",
    "scripts/aggregate_all.py",
    "scripts/audit_seed_statistics.py",
    "scripts/verify_reviewer_completeness.py",
    "scripts/hash_reviewer_artifacts.py",
    "scripts/export_reviewer_artifacts.py",
    "src/mhsolkt/models/mhsolkt.py",
    "src/mhsolkt/models/baselines.py",
    "src/mhsolkt/training/engine.py",
    "src/mhsolkt/training/losses.py",
    "src/mhsolkt/evaluation/calibration.py",
    "src/mhsolkt/evaluation/uncertainty.py",
    "src/mhsolkt/evaluation/intervention.py",
    "src/mhsolkt/evaluation/statistics.py",
    "tests/test_fivefold_aggregation.py",
]


def validate_baseline_classes() -> None:
    path = ROOT / "src/mhsolkt/models/baselines.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    expected = {"DKT", "DKVMN", "SAKT", "SAINT", "AKT", "GIKT", "SimpleKT", "CausalTransformer"}
    found = set()
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name in expected:
            found.add(node.name)
            if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                raise SystemExit(f"Baseline {node.name} is an empty alias/pass class.")
    if found != expected:
        raise SystemExit(f"Missing baseline classes: {sorted(expected - found)}")


def validate_proposed_depth() -> None:
    for cfg_path in (ROOT / "configs/proposed").glob("*.yaml"):
        cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        m = cfg["model"]
        if "layers" in m:
            raise SystemExit(f"{cfg_path}: ambiguous generic layers field is not allowed for the hybrid model")
        if m.get("use_ssm", True) and int(m.get("ssm_layers", 0)) < 1:
            raise SystemExit(f"{cfg_path}: explicit ssm_layers is required")
        if m.get("use_lstm", True) and int(m.get("lstm_layers", 0)) < 1:
            raise SystemExit(f"{cfg_path}: explicit lstm_layers is required")
        if m.get("use_graph", True) and int(m.get("graph_layers", 0)) < 1:
            raise SystemExit(f"{cfg_path}: explicit graph_layers is required")


def validate_ablation_uniqueness() -> None:
    signatures = {}
    for cfg_path in (ROOT / "configs/ablations").glob("*.yaml"):
        cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        m = cfg["model"]
        signature = tuple(bool(m.get(k, default)) for k, default in [
            ("use_ssm", True), ("use_lstm", True), ("use_graph", True),
            ("use_mastery_head", True), ("use_uncertainty_head", True),
        ])
        if signature in signatures:
            raise SystemExit(f"Duplicate ablation structures: {signatures[signature]} and {cfg_path}")
        signatures[signature] = cfg_path


def validate_diagnostic_training() -> None:
    cfg = yaml.safe_load((ROOT / "configs/common.yaml").read_text(encoding="utf-8"))
    loss = cfg["loss"]
    if float(loss.get("mastery_weight", 0)) <= 0 or float(loss.get("uncertainty_weight", 0)) <= 0:
        raise SystemExit("Diagnostic heads must have explicit nonzero training weights for meaningful head ablations.")


def validate_source_only_archive() -> None:
    # Reviewer-evidence archives may include outputs/ with formal logs and metrics.
    return


def main():
    missing = [p for p in EXPECTED if not (ROOT / p).exists()]
    if missing:
        raise SystemExit(f"Missing required files: {missing}")
    for cfg in (ROOT / "configs").rglob("*.yaml"):
        with cfg.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            raise SystemExit(f"Invalid YAML mapping: {cfg}")
    validate_baseline_classes()
    validate_proposed_depth()
    validate_ablation_uniqueness()
    validate_diagnostic_training()
    validate_source_only_archive()
    ok = compileall.compile_dir(ROOT / "src", quiet=1) and compileall.compile_dir(ROOT / "scripts", quiet=1)
    if not ok:
        raise SystemExit("Python compilation failed.")
    print("Package structure, YAML syntax, distinct baseline implementations, explicit branch-depth alignment, ablation uniqueness, diagnostic training, artifact policy, and Python compilation checks passed.")


if __name__ == "__main__":
    main()
