# Model implementation notes

The reproduced baselines are implemented as distinct architecture families rather than class aliases.

- **DKT**: LSTM learner-state sequence model.
- **DKVMN**: static key memory plus dynamically updated value memory with erase/add operations.
- **SAKT**: question embeddings form queries; response-conditioned interaction embeddings form keys and values.
- **SAINT**: exercise encoder and response decoder.
- **AKT**: question/interaction attention with learned monotonic distance decay and item-difficulty modulation.
- **GIKT**: item-concept graph propagation combined with recurrent interaction tracking and gated fusion.
- **SimpleKT**: compact KT-specific causal attention with item-difficulty modulation and a smaller feed-forward path.
- **Causal Transformer**: generic causal Transformer over the common interaction representation.

Every run writes `model_provenance.json`. The package does not represent independently reimplemented code as official upstream code; it records the actual implementation executed by this repository.
