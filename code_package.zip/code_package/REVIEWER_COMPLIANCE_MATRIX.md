# Reviewer compliance matrix

This matrix maps each reproducibility concern to the exact code path and generated evidence.

| Reviewer concern | Code response | Generated evidence |
|---|---|---|
| Table 7 paired statistics must reproduce from Table 6 seed values | `scripts/aggregate_all.py`, `src/mhsolkt/evaluation/statistics.py`, `scripts/audit_seed_statistics.py` | `primary_seed_level_source.csv`, `paired_auc_statistics.csv`, exact audit pass |
| Provide per-seed raw outputs | Every formal run exports metrics and prediction arrays | per-seed `final_test_metrics.json`, `validation_predictions.npz`, `test_predictions.npz` |
| Explain and document official Mamba environment | Separate pinned environment and environment validator | `environment-official-mamba.yml`, `requirements-official-mamba.txt`, `official_mamba_environment_check.json`, per-run `environment.json` |
| Release baseline reproduction code | Distinct baseline classes in `src/mhsolkt/models/baselines.py` | `model_provenance.json` for each run |
| Release exact configurations | YAML configs plus resolved runtime configs | source YAML and per-run `resolved_config.json` |
| Document model-specific validation grid | `configs/tuning_grids/baselines.yaml`, `scripts/run_hyperparameter_search.py` | validation search logs, rankings, selected config, selection record |
| Provide per-seed training logs | Formal training engine | `training_history.csv` |
| Provide training curves | Formal training engine | `training_curve.png` |
| Provide checkpoint validation AUCs | Formal training engine | `validation_auc_history.csv`, `checkpoint_metadata.json` |
| Provide final test metrics | Formal training engine | `final_test_metrics.json` |
| Prevent test-driven tuning | Validation-only tuning mode | `evaluation.evaluate_test=false`, `selection_record.json` |
| Remove duplicate ablations | Unique structural configs and package validator | six unique ablation YAML files; duplicate-signature validation |
| Correct student-wise five-fold aggregation | Explicit two-stage aggregator | fold-level CSV, per-seed fold-average CSV, across-seed summary CSV |
| Verify evidence completeness before submission | `scripts/verify_reviewer_completeness.py` | `reviewer_completeness_report.json` |
| Protect artifact integrity | `scripts/hash_reviewer_artifacts.py` | `SHA256SUMS.txt` |
