# Full reproduction checklist

1. Install the base environment.
2. Obtain the authorized SingPAD/SingKT raw data.
3. Map the real source columns in `configs/common.yaml`.
4. Run preprocessing and all split constructors.
5. Run the predefined validation-only baseline grid search and preserve its selection logs.
6. Run the primary five-seed comparison.
7. Run all unique ablations.
8. Run fallback Mamba sensitivity in the primary environment.
9. Create and validate the pinned official-Mamba environment.
10. Run official-kernel sensitivity in that environment.
11. Run hidden-size and sequence-length sensitivity.
12. Run calibration variants and post-hoc temperature scaling.
13. Run uncertainty-error alignment.
14. Run top-risk intervention analysis.
15. Run protocol robustness checks, including all 5 folds within each seed.
16. Run parameter-count and measured-epoch-runtime analysis.
17. Export a representative trajectory from a real primary run.
18. Run smoke and toy pipeline checks.
19. Aggregate all outputs.
20. Audit Tables 5-7 paired seed statistics from the same source CSV.
21. Verify reviewer completeness.
22. Generate SHA-256 checksums.
23. Export the reviewer-facing evidence archive.

The submission gate is:

```bash
python scripts/verify_reviewer_completeness.py
```

Do not state that reviewer materials are available until this command passes on the real experiment outputs.

No paper result is hardcoded in this package. All numerical outputs must come from actual execution on the authorized dataset.
