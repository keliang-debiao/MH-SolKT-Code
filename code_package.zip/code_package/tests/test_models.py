import torch
torch.set_num_threads(1)
from mhsolkt.models.registry import build_model
from mhsolkt.training.losses import compute_loss

META = {
    "num_items": 32,
    "num_concepts": 12,
    "num_scores": 8,
    "aux_dim": 2,
    "item_concept_edges": [[i, (i % 10) + 1] for i in range(1, 31)],
}


def batch():
    return {
        "item_id": torch.randint(1, 31, (2, 9)),
        "concept_id": torch.randint(1, 11, (2, 9)),
        "score_id": torch.randint(1, 7, (2, 9)),
        "response": torch.randint(0, 2, (2, 9)).float(),
        "aux": torch.randn(2, 9, 2),
        "mask": torch.ones(2, 9, dtype=torch.bool),
    }


def config(name):
    base = {"embedding_dim": 16, "hidden_dim": 32, "layers": 2, "heads": 4, "dropout": 0.1}
    if name == "mhsolkt":
        base.update({
            "use_ssm": True,
            "use_lstm": True,
            "use_graph": True,
            "use_mastery_head": True,
            "use_uncertainty_head": True,
            "graph_layers": 1,
            "mamba_impl": "fallback",
            "sequence_layers": 2,
            "mamba_layers": 2,
            "lstm_layers": 2,
        })
    if name == "gikt":
        base.update({"graph_layers": 1})
    return {"model": {"name": name, **base}}


def test_forward_shapes():
    for name in ["dkt", "dkvmn", "sakt", "saint", "akt", "gikt", "simplekt", "causal_transformer", "mhsolkt"]:
        model = build_model(META, config(name))
        out = model(batch())
        assert out["logits"].shape == (2, 9)


def test_baselines_are_distinct_implementations():
    names = ["dkvmn", "sakt", "saint", "akt", "gikt", "simplekt", "causal_transformer"]
    classes = [type(build_model(META, config(name))) for name in names]
    assert len(set(classes)) == len(names)
    sakt = build_model(META, config("sakt"))
    causal = build_model(META, config("causal_transformer"))
    assert hasattr(sakt, "blocks") and not hasattr(sakt, "transformer")
    assert hasattr(causal, "transformer")


def test_mhsolkt_declared_depth_is_used():
    model = build_model(META, config("mhsolkt"))
    assert len(model.ssm.blocks) == 2
    assert model.lstm.num_layers == 2


def test_auxiliary_heads_receive_gradients_when_enabled():
    model = build_model(META, config("mhsolkt"))
    b = batch()
    inputs = {k: v[:, :-1] for k, v in b.items()}
    targets = b["response"][:, 1:]
    valid = b["mask"][:, :-1] & b["mask"][:, 1:]
    outputs = model(inputs)
    cfg = {
        "loss": {
            "type": "bce",
            "mastery_weight": 0.02,
            "uncertainty_weight": 0.02,
            "brier_weight": 0.0,
            "label_smoothing": 0.0,
        }
    }
    loss = compute_loss(outputs, targets, valid, cfg, inputs=inputs)
    loss.backward()
    assert model.mastery_head.weight.grad is not None
    assert model.uncertainty_head.weight.grad is not None
