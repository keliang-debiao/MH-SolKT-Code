import numpy as np
from mhsolkt.evaluation.statistics import paired_summary


def test_paired_summary_uses_sample_sd():
    a = np.array([0.9, 0.8, 0.7, 0.6, 0.5])
    b = np.array([0.8, 0.7, 0.6, 0.5, 0.4])
    out = paired_summary(a, b)
    assert np.isclose(out["mean_delta"], 0.1)
    assert np.isclose(out["paired_sd"], np.std(a - b, ddof=1))
    assert out["n"] == 5
