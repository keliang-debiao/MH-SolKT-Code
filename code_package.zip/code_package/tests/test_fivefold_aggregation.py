import json
from pathlib import Path

from scripts.aggregate_protocol_fivefold import aggregate_fivefold


def test_two_stage_fivefold_aggregation(tmp_path: Path):
    root = tmp_path / "outputs"
    for model in ["dkt", "mhsolkt_384"]:
        for seed in [2024, 2025]:
            for fold in range(5):
                run = root / "protocol_robustness" / "student_wise_fivefold" / model / f"seed_{seed}" / f"fold_{fold}"
                run.mkdir(parents=True)
                (run / "run_metadata.json").write_text(json.dumps({
                    "configuration_name": model,
                    "seed": seed,
                    "fold": fold,
                    "family": "protocol_robustness",
                }))
                value = 0.80 + 0.01 * (model == "mhsolkt_384") + 0.001 * fold + 0.0001 * (seed - 2024)
                (run / "final_test_metrics.json").write_text(json.dumps({"auc": value, "acc": value - 0.02}))
    runs, per_seed, summary = aggregate_fivefold(root)
    assert len(runs) == 20
    assert len(per_seed) == 4
    assert set(summary["configuration_name"]) == {"dkt", "mhsolkt_384"}
