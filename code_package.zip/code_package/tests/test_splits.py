from mhsolkt.data.splits import assert_no_student_overlap


def test_nonoverlap():
    assert_no_student_overlap({"train_indices": [1, 2], "val_indices": [3], "test_indices": [4]})
